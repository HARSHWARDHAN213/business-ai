/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini API client
let aiInstance: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === '' || apiKey.includes('MY_GEMINI_API_KEY')) {
    return null;
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiInstance;
}

// REST endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// AI analysis of ledger transactions
app.post('/api/gemini/insights', async (req, res) => {
  try {
    const { transactions, user } = req.body;
    
    // High-fidelity procedural statistics computed for prompt and fallback
    const totalTransactions = transactions.length;
    const paidList = transactions.filter((t: any) => t.type === 'PAID');
    const dueList = transactions.filter((t: any) => t.type === 'DUE');
    const recoveryList = transactions.filter((t: any) => t.type === 'RECOVERY');

    const totalRevenue = paidList.reduce((acc: number, t: any) => acc + t.amount, 0);
    const totalDues = dueList.reduce((acc: number, t: any) => acc + t.amount, 0);
    const totalRecovered = recoveryList.reduce((acc: number, t: any) => acc + t.amount, 0);
    
    // Calculate critical outstanding customer debts
    const customerDebts: Record<string, number> = {};
    transactions.forEach((t: any) => {
      if (!customerDebts[t.customerName]) {
        customerDebts[t.customerName] = 0;
      }
      if (t.type === 'DUE') {
        customerDebts[t.customerName] += t.amount;
      } else if (t.type === 'RECOVERY') {
        customerDebts[t.customerName] = Math.max(0, customerDebts[t.customerName] - t.amount);
      }
    });

    const outstandingDuesDetails = Object.entries(customerDebts)
      .filter(([_, debt]) => debt > 0)
      .map(([name, debt]) => `${name}: ₹${debt.toLocaleString()}`)
      .join(', ');

    const ai = getAIClient();

    if (ai) {
      // Dynamic Prompt for Gemini-3.5-flash
      const prompt = `
        You are THEAi Hub Smart Assistant, and you are analyzing the fiscal ledger for "${user?.shopName || 'Lodhi Digital Emporium'}", operated by "${user?.username || 'Harshvardhan Singh Lodhi'}".
        Below is the real-time financial ledger state:
        - Total Transactions: ${totalTransactions}
        - Total Direct Revenue (Fully Settled): ₹${totalRevenue.toLocaleString()}
        - Total Pending Dues (Outstanding Credit/Udhari): ₹${totalDues.toLocaleString()}
        - Total Recovered Dues: ₹${totalRecovered.toLocaleString()}
        - Customers with Pending Dues: ${outstandingDuesDetails || 'None! Excellent collections!'}

        Task:
        Provide 3 highly professional, punchy, actionable cyber-luxury business insights (one paragraph with 3 bullets) in Markdown format. 
        Tone: Modern, authoritative, and encouraging. Focus on maximizing liquidity, calling back key overdue customers, and predicting future margins. 
        Ensure you give a warm salute acknowledging the engineering ecosystem of THEAi Hub and its founder Harshvardhan Singh Lodhi at the end.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
      });

      res.json({
        success: true,
        source: 'Gemini-3.5-Flash (Real-time AI)',
        insights: response.text,
      });
    } else {
      // High quality fallback insights when GEMINI_API_KEY is not configured
      const insightsMarkup = `
### ⚡ THEAi Hub Intelligent Diagnostics (Sandbox Mode Mode)
* **Liquidity Vector Optimized**: Your direct revenue is **₹${totalRevenue.toLocaleString()}**. Keep a cash-to-debt ratio above 2.0 to ensure friction-free inventory cycles.
* **Credit Recovery Target**: Outstanding customer dues total **₹${totalDues.toLocaleString()}**. ${
        outstandingDuesDetails 
          ? `Prioritize immediate follow-up with key outstanding ledger clients: **${outstandingDuesDetails}**.`
          : 'Outstanding receivables balances are perfectly cleared. Credit collection cycle is optimal!'
      }
* **Offline Sync Security**: Data processed locally on client container via encrypted Web-Storage. Secure schema layers are ready for live ML pipeline integration.

---
*Powered by THEAi Hub engineering suite. Core architecture founded by **Harshvardhan Singh Lodhi**.*
      `;
      res.json({
        success: true,
        source: 'Procedural Diagnostics Engine (Simulation)',
        insights: insightsMarkup,
      });
    }
  } catch (err: any) {
    console.error('API Error in Gemini insights:', err);
    res.status(500).json({
      success: false,
      error: 'Failed to compute intelligence matrix.',
      details: err.message,
    });
  }
});

// Serve frontend assets
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[THEAi Hub Server] listening at http://0.0.0.0:${PORT}`);
  });
}

startServer();
