/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Transaction } from '../types';

/**
 * Builds a gorgeous HTML email payload for a single Transaction Bill Invoice
 */
export function generateEmailHtmlForTransaction(t: Transaction, shopName: string, username: string): string {
  const isBilledInvoice = t.items && t.items.length > 0;
  const subtotal = isBilledInvoice 
    ? t.items.reduce((sum, item) => sum + (item.quantity * item.price), 0)
    : t.amount;
  const tax = isBilledInvoice ? Math.round(subtotal * 0.05) : 0;
  
  const rows = isBilledInvoice
    ? t.items.map(item => `
        <tr style="border-bottom: 1px solid #eeeeee;">
          <td style="padding: 12px 10px; text-align: left; font-family: sans-serif; font-size: 13px; color: #333333;">${item.name}</td>
          <td style="padding: 12px 10px; text-align: center; font-family: monospace; font-size: 13px; color: #555555;">${item.quantity}</td>
          <td style="padding: 12px 10px; text-align: right; font-family: monospace; font-size: 13px; color: #555555;">₹${item.price.toLocaleString()}</td>
          <td style="padding: 12px 10px; text-align: right; font-family: monospace; font-weight: bold; font-size: 13px; color: #111111;">₹${(item.quantity * item.price).toLocaleString()}</td>
        </tr>
      `).join('')
    : `
        <tr style="border-bottom: 1px solid #eeeeee;">
          <td style="padding: 12px 10px; text-align: left; font-family: sans-serif; font-size: 13px; color: #333333;">${t.description || 'Ledger transaction detail'}</td>
          <td style="padding: 12px 10px; text-align: center; font-family: monospace; font-size: 13px; color: #555555;">1</td>
          <td style="padding: 12px 10px; text-align: right; font-family: monospace; font-size: 13px; color: #555555;">₹${t.amount.toLocaleString()}</td>
          <td style="padding: 12px 10px; text-align: right; font-family: monospace; font-weight: bold; font-size: 13px; color: #111111;">₹${t.amount.toLocaleString()}</td>
        </tr>
      `;

  return `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
      <div style="text-align: center; border-bottom: 2px solid #ff007f; padding-bottom: 15px; margin-bottom: 20px;">
        <h2 style="margin: 0; color: #000000; font-size: 24px; font-weight: 800; tracking: -0.5px;">THE <span style="color: #ff007f;">Ai Hub</span></h2>
        <p style="margin: 5px 0 0; font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #64748b; font-weight: bold;">${shopName}</p>
        <p style="margin: 2px 0 0; font-size: 10px; color: #94a3b8;">Operator Signature: ${username}</p>
      </div>
      
      <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; padding: 15px; border-radius: 12px; margin-bottom: 20px; font-size: 12px; line-height: 1.6; color: #475569;">
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="vertical-align: top; padding-bottom: 5px;">
              <strong style="color: #0f172a;">BILL INVOICE ID:</strong><br/>
              <span style="font-family: monospace; font-size: 13px; font-weight: bold; color: #0f172a;">${t.billId}</span>
            </td>
            <td style="vertical-align: top; text-align: right; padding-bottom: 5px;">
              <strong style="color: #0f172a;">DATE TIME:</strong><br/>
              <span style="font-family: monospace; font-size: 12px; color: #0f172a;">${new Date(t.date).toLocaleString()}</span>
            </td>
          </tr>
          <tr>
            <td style="vertical-align: top; padding-top: 5px;">
              <strong style="color: #0f172a;">CLIENT NAME:</strong><br/>
              <span style="font-size: 13px; font-weight: bold; text-transform: uppercase; color: #0f172a;">${t.customerName}</span><br/>
              <span style="font-size: 11px; color: #64748b;">${t.customerPhone || 'No contact saved'}</span>
            </td>
            <td style="vertical-align: top; text-align: right; padding-top: 5px;">
              <strong style="color: #0f172a;">CLASSIFIED:</strong><br/>
              <span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 10px; font-weight: bold; text-transform: uppercase; background-color: ${t.type === 'PAID' ? 'rgba(16,185,129,0.1)' : t.type === 'DUE' ? 'rgba(239,68,68,0.1)' : 'rgba(6,182,212,0.1)'}; color: ${t.type === 'PAID' ? '#10b981' : t.type === 'DUE' ? '#ef4444' : '#06b6d4'}; border: 1px solid ${t.type === 'PAID' ? 'rgba(16,185,129,0.2)' : t.type === 'DUE' ? 'rgba(239,68,68,0.2)' : 'rgba(6,182,212,0.2)'};">${t.type}</span>
            </td>
          </tr>
        </table>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 20px;">
        <thead>
          <tr style="background-color: #f8fafc; border-bottom: 1px solid #e2e8f0;">
            <th style="padding: 12px 10px; text-align: left; font-size: 10px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 1px;">SPECIFICATION</th>
            <th style="padding: 12px 10px; text-align: center; width: 50px; font-size: 10px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 1px;">QTY</th>
            <th style="padding: 12px 10px; text-align: right; width: 80px; font-size: 10px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 1px;">PRICE</th>
            <th style="padding: 12px 10px; text-align: right; width: 100px; font-size: 10px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 1px;">TOTAL</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>

      <div style="border-top: 1px dashed #e2e8f0; padding-top: 15px; font-size: 13px;">
        <table style="width: 100%; border-collapse: collapse; color: #64748b;">
          <tr>
            <td style="padding: 4px 0; text-align: left;">Subtotal Compilations:</td>
            <td style="padding: 4px 0; text-align: right; font-family: monospace; color: #334155;">₹${subtotal.toLocaleString()}</td>
          </tr>
          <tr>
            <td style="padding: 4px 0; text-align: left;">Convenience handling tax (5%):</td>
            <td style="padding: 4px 0; text-align: right; font-family: monospace; color: #334155;">₹${tax.toLocaleString()}</td>
          </tr>
          <tr style="border-top: 1px solid #475569;">
            <td style="padding: 15px 0 0; text-align: left; font-size: 15px; font-weight: bold; color: #0f172a;">GRAND TOTAL REVENUE:</td>
            <td style="padding: 15px 0 0; text-align: right; font-family: monospace; font-size: 18px; font-weight: 800; color: #ff007f;">₹${t.amount.toLocaleString()}</td>
          </tr>
        </table>
      </div>

      <div style="text-align: center; margin-top: 35px; border-top: 1px solid #f1f5f9; padding-top: 18px; font-size: 9px; color: #94a3b8; line-height: 1.6; font-family: monospace; text-transform: uppercase; letter-spacing: 0.5px;">
        TRANSACTION SECURITY TOKEN &bull; ${t.id.toUpperCase()}<br/>
        DEVELOPED FOR THEAI HUB ENGINE SECURED ACCESS PROTOCOL<br/>
        COGNITIVE DOCK SYNCED VIET GMAIL GATEWAY
      </div>
    </div>
  `;
}

/**
 * Builds a gorgeous HTML email payload for a complete client-wise Statement timeline
 */
export function generateEmailHtmlForStatement(customerName: string, customerData: any, shopName: string, username: string): string {
  const txnRows = customerData.transactions.map((t: Transaction) => `
    <tr style="border-bottom: 1px solid #f1f5f9;">
      <td style="padding: 10px; font-family: monospace; font-size: 12px; color: #334155;">${new Date(t.date).toLocaleDateString()}</td>
      <td style="padding: 10px; font-family: monospace; font-weight: bold; font-size: 12px; color: #0f172a;">${t.billId}</td>
      <td style="padding: 10px;">
        <span style="display: inline-block; padding: 2px 6px; font-size: 9px; font-weight: bold; text-transform: uppercase; border-radius: 4px; background-color: ${t.type === 'DUE' ? 'rgba(239,68,68,0.1)' : t.type === 'RECOVERY' ? 'rgba(6,182,212,0.1)' : 'rgba(16,185,129,0.1)'}; color: ${t.type === 'DUE' ? '#ef4444' : t.type === 'RECOVERY' ? '#06b6d4' : '#10b981'};">${t.type}</span>
      </td>
      <td style="padding: 10px; font-size: 12px; color: #475569;">${t.description || 'Ledger transaction record'}</td>
      <td style="padding: 10px; text-align: right; font-family: monospace; font-weight: bold; font-size: 12px; color: #0f172a;">₹${t.amount.toLocaleString()}</td>
    </tr>
  `).join('');

  return `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 650px; margin: 20px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
      <div style="text-align: center; border-bottom: 2px solid #00f0ff; padding-bottom: 15px; margin-bottom: 20px;">
        <h2 style="margin: 0; color: #000000; font-size: 24px; font-weight: 800; tracking: -0.5px;">THE <span style="color: #00f0ff;">Ai Hub</span></h2>
        <p style="margin: 5px 0 0; font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #64748b; font-weight: bold;">AUDITED CUSTOMER DUES STATEMENT STATEMENT</p>
        <p style="margin: 2px 0 0; font-size: 10px; color: #94a3b8;">Store Node: ${shopName} | Operator Signature: ${username}</p>
      </div>

      <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; padding: 15px; border-radius: 12px; margin-bottom: 20px; font-size: 12px; line-height: 1.6; color: #475569;">
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td>
              <strong style="color: #0f172a; text-transform: uppercase;">Customer Account Identity:</strong><br/>
              <span style="font-size: 15px; font-weight: bold; color: #0f172a; text-transform: uppercase;">${customerName}</span><br/>
              <span style="font-size: 11px; color: #64748b;">Phone: ${customerData.phone || 'No phone attached'}</span>
            </td>
            <td style="text-align: right; vertical-align: top;">
              <strong style="color: #0f172a;">STATEMENT DATE:</strong><br/>
              <span style="font-family: monospace; font-size: 12px; color: #0f172a;">${new Date().toLocaleDateString()}</span><br/>
              <span style="display: inline-block; padding: 2px 6px; margin-top: 5px; border-radius: 4px; font-size: 10px; font-weight: bold; background-color: ${customerData.balance > 0 ? 'rgba(239,68,68,0.1)' : 'rgba(16,185,129,0.1)'}; color: ${customerData.balance > 0 ? '#ef4444' : '#10b981'};">${customerData.balance > 0 ? 'OVERDUE BALANCE' : 'FULLY CLEARED'}</span>
            </td>
          </tr>
        </table>
      </div>

      <div style="margin-bottom: 25px;">
        <table style="width: 100%; border-collapse: collapse; text-align: center;">
          <tr>
            <td style="width: 33%; padding: 5px;">
              <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 10px;">
                <span style="font-size: 9px; text-transform: uppercase; color: #64748b; font-weight: bold;">Total Purchases</span><br/>
                <span style="font-family: monospace; font-size: 16px; font-weight: bold; color: #0f172a;">₹${customerData.totalBilled.toLocaleString()}</span>
              </div>
            </td>
            <td style="width: 33%; padding: 5px;">
              <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; padding: 12px 10px;">
                <span style="font-size: 9px; text-transform: uppercase; color: #166534; font-weight: bold;">Payments Cleared</span><br/>
                <span style="font-family: monospace; font-size: 16px; font-weight: bold; color: #166534;">₹${customerData.totalPaid.toLocaleString()}</span>
              </div>
            </td>
            <td style="width: 33%; padding: 5px;">
              <div style="background-color: ${customerData.balance > 0 ? '#fef2f2' : '#f0fdf4'}; border: 1px solid ${customerData.balance > 0 ? '#fecaca' : '#bbf7d0'}; border-radius: 10px; padding: 12px 10px;">
                <span style="font-size: 9px; text-transform: uppercase; color: ${customerData.balance > 0 ? '#991b1b' : '#166534'}; font-weight: bold;">Net Pending</span><br/>
                <span style="font-family: monospace; font-size: 16px; font-weight: 800; color: ${customerData.balance > 0 ? '#ef4444' : '#10b981'};">₹${customerData.balance.toLocaleString()}</span>
              </div>
            </td>
          </tr>
        </table>
      </div>

      <h4 style="font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; color: #64748b; border-bottom: 1.5px solid #e2e8f0; padding-bottom: 6px; margin: 0 0 10px 0; font-weight: bold;">Itemized Transaction Chronology Log</h4>
      <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
        <thead>
          <tr style="background-color: #f8fafc; border-bottom: 1px solid #cbd5e1; text-align: left;">
            <th style="padding: 8px 10px; text-transform: uppercase; font-size: 9px; color: #64748b; font-weight: bold;">DATE</th>
            <th style="padding: 8px 10px; text-transform: uppercase; font-size: 9px; color: #64748b; font-weight: bold;">BILL REF</th>
            <th style="padding: 8px 10px; text-transform: uppercase; font-size: 9px; color: #64748b; font-weight: bold;">TYPE</th>
            <th style="padding: 8px 10px; text-transform: uppercase; font-size: 9px; color: #64748b; font-weight: bold;">INTERNAL MEMO</th>
            <th style="padding: 8px 10px; text-transform: uppercase; font-size: 9px; color: #64748b; font-weight: bold; text-align: right;">AMOUNT</th>
          </tr>
        </thead>
        <tbody>
          ${txnRows}
        </tbody>
      </table>

      <div style="text-align: center; margin-top: 40px; border-top: 1px solid #f1f5f9; padding-top: 18px; font-size: 9px; color: #94a3b8; line-height: 1.6; font-family: monospace; text-transform: uppercase; letter-spacing: 0.5px;">
        THEAI HUB INTEGRATED DIGITAL LEDGER AUDITED EXPORT<br/>
        DEVELOPER SIGNATURE SYSTEMS WRITTEN BY HARSHVARDHAN SINGH LODHI<br/>
        ENCRYPTED CLOUD BROADCAST SECURED NODE SYNC
      </div>
    </div>
  `;
}
