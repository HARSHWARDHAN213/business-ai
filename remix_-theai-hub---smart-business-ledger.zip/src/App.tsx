/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { AppTheme, UserSession } from './types';
import LoginScreen from './components/LoginScreen';
import Dashboard from './components/Dashboard';
import { auth, db, testConnection } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { disconnectGmail } from './gmail';

export default function App() {
  const [session, setSession] = useState<UserSession>({
    isLoggedIn: false,
    username: '',
    email: '',
    shopName: ''
  });
  const [authReady, setAuthReady] = useState(false);

  const [theme, setTheme] = useState<AppTheme>(() => {
    const saved = localStorage.getItem('THEAI_HUB_SELECTED_THEME');
    return (saved as AppTheme) || 'MIDNIGHT_VELOCITY';
  });

  // Keep theme synced physically inside localStorage
  useEffect(() => {
    localStorage.setItem('THEAI_HUB_SELECTED_THEME', theme);
  }, [theme]);

  // Handle Firebase connection test first time
  useEffect(() => {
    testConnection();
  }, []);

  // Set up Firebase auth observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser && firebaseUser.email) {
        // Authenticated. Let's fetch their user profile from Firestore users collection
        try {
          const userDocRef = doc(db, 'users', firebaseUser.email);
          const userSnap = await getDoc(userDocRef);
          
          if (userSnap.exists()) {
            const data = userSnap.data();
            const loadedSession: UserSession = {
              isLoggedIn: true,
              username: data.username || firebaseUser.displayName || 'Operator',
              email: firebaseUser.email,
              shopName: data.shopName || 'The AI Hub'
            };
            setSession(loadedSession);
            localStorage.setItem('THEAI_HUB_AUTH_SESSION', JSON.stringify(loadedSession));
          } else {
            // Create user profile for the first time
            const shopNameVal = localStorage.getItem('THEAI_HUB_PENDING_SHOPNAME') || 'The AI Hub';
            const usernameVal = firebaseUser.displayName || 'Authorized Operator';
            
            await setDoc(userDocRef, {
              email: firebaseUser.email,
              username: usernameVal,
              shopName: shopNameVal,
              updatedAt: new Date().toISOString()
            });

            const freshSession: UserSession = {
              isLoggedIn: true,
              username: usernameVal,
              email: firebaseUser.email,
              shopName: shopNameVal
            };
            setSession(freshSession);
            localStorage.setItem('THEAI_HUB_AUTH_SESSION', JSON.stringify(freshSession));
            localStorage.removeItem('THEAI_HUB_PENDING_SHOPNAME');
          }
        } catch (e) {
          console.error("Error setting up user profile document:", e);
          const fallbackSession: UserSession = {
            isLoggedIn: true,
            username: firebaseUser.displayName || 'Operator',
            email: firebaseUser.email,
            shopName: 'The AI Hub'
          };
          setSession(fallbackSession);
          localStorage.setItem('THEAI_HUB_AUTH_SESSION', JSON.stringify(fallbackSession));
        }
      } else {
        // Not logged in to Firebase. Let's check local storage fallback
        const saved = localStorage.getItem('THEAI_HUB_AUTH_SESSION');
        if (saved) {
          try {
            setSession(JSON.parse(saved));
          } catch {
            setSession({ isLoggedIn: false, username: '', email: '', shopName: '' });
          }
        } else {
          setSession({ isLoggedIn: false, username: '', email: '', shopName: '' });
        }
      }
      setAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  const handleLoginSuccess = (newSession: UserSession) => {
    setSession(newSession);
    localStorage.setItem('THEAI_HUB_AUTH_SESSION', JSON.stringify(newSession));
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      disconnectGmail();
    } catch (e) {
      console.error("Error signing out from Firebase Auth:", e);
    }
    const freshSession = {
      isLoggedIn: false,
      username: '',
      email: '',
      shopName: ''
    };
    setSession(freshSession);
    localStorage.removeItem('THEAI_HUB_AUTH_SESSION');
  };

  if (!authReady) {
    return (
      <div className={`min-h-screen flex flex-col justify-center items-center font-mono text-xs ${
        theme === 'NEON_MONOCHROME' ? 'bg-[#030303] text-emerald-400' : 'bg-[#010103] text-white'
      }`}>
        <div className="flex flex-col items-center gap-4">
          <div className={`w-8 h-8 rounded-full border-2 animate-spin ${
            theme === 'NEON_MONOCHROME' ? 'border-emerald-500 border-t-transparent' : 'border-fuchsia-500 border-t-transparent'
          }`}></div>
          <span className="uppercase tracking-widest animate-pulse">Initializing Security Protocol...</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen text-slate-100 transition-colors duration-500 font-sans ${
      theme === 'NEON_MONOCHROME' 
        ? 'bg-[#030303] text-emerald-400 selection:bg-emerald-500/30 selection:text-emerald-300' 
        : 'bg-[#010103] text-neutral-200 selection:bg-fuchsia-500/30 selection:text-fuchsia-300'
    }`}>
      {/* Scanlines layer for immersive aesthetic depth */}
      <div className="fixed inset-0 pointer-events-none z-50 opacity-[0.03] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_4px,3px_100%]"></div>

      {session.isLoggedIn ? (
        <Dashboard 
          session={session} 
          theme={theme} 
          onChangeTheme={setTheme} 
          onLogout={handleLogout} 
        />
      ) : (
        <LoginScreen 
          onLoginSuccess={handleLoginSuccess} 
          theme={theme} 
        />
      )}
    </div>
  );
}
