/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TransactionItem {
  name: string;
  quantity: number;
  price: number;
}

export type TransactionType = 'PAID' | 'DUE' | 'RECOVERY';

export interface Transaction {
  id: string;
  billId: string;
  customerName: string;
  customerPhone?: string;
  amount: number;
  type: TransactionType;
  description: string;
  date: string;
  items: TransactionItem[];
}

export type AppTheme = 'NEON_MONOCHROME' | 'MIDNIGHT_VELOCITY';

export interface UserSession {
  isLoggedIn: boolean;
  username: string;
  email: string;
  shopName: string;
}
