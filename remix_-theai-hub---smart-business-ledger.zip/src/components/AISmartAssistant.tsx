/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Sparkles, RefreshCw, AlertCircle, Info, ShieldCheck, Heart } from 'lucide-react';
import { Transaction, AppTheme, UserSession } from '../types';

interface AISmartAssistantProps {
  transactions: Transaction[];
  session: UserSession;
  theme: AppTheme;
}

export default function AISmartAssistant({ transactions, session, theme }: AISmartAssistantProps) {
  const isNeon = theme === 'NEON_MONOCHROME';
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [insights, setInsights] = useState<string | null>(null);
  const [source, setSource] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Decorative diagnostic console feedback
  const triggerDiagnostics = async () => {
    setLoading(true);
    setInsights(null);
    setError(null);
    setLogs([]);

    const logSteps = [
      '🚀 INITIALIZING THEAi HUB ML PIPELINE...',
      '📡 PARSING CENTRAL LOCAL STORAGE LEDGER MATRIX...',
      '📊 COMPUTING CONSECUTIVE LIQUIDITY VECTORS...',
      '🔍 COMPILING OUTSTANDING CREDIT & UDHARI COEFFICIENTS...',
      '🧠 TRANSMITTING SEGMENTED SCHEMAS TO GEMINI INFERENCE MATRIX...'
    ];

    // Play immersive diagnostics console log build up
    for (let i = 0; i < logSteps.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 450));
      setLogs((prev) => [...prev, logSteps[i]]);
    }

    try {
      const response = await fetch('/api/gemini/insights', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          transactions,
          user: session
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP Error status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        setInsights(data.insights);
        setSource(data.source);
      } else {
        throw new Error(data.error || 'Unknown analysis failure.');
      }
    } catch (err: any) {
      console.error(err);
      setError('Connection to raw inference node timed out. Please verify local environment config.');
    } finally {
      setLoading(false);
    }
  };

  // Modern micro renderer that formats markdown bullet lines into stylish components
  const renderInsights = (rawText: string) => {
    const lines = rawText.split('\n');
    return lines.map((line, idx) => {
      const trimmed = line.trim();
      if (!trimmed) return <div key={idx} className="h-2"></div>;

      // Handle main title headers
      if (trimmed.startsWith('###')) {
        return (
          <h4 key={idx} className="text-sm font-bold tracking-tight text-white uppercase mt-4 mb-2 flex items-center gap-1.5 font-mono">
            <span className="w-1.5 h-3 bg-emerald-400"></span>
            {trimmed.replace('###', '').trim()}
          </h4>
        );
      }

      // Handle bold item lines starting with markdown *
      if (trimmed.startsWith('*')) {
        const payload = trimmed.substring(1).trim();
        const boldSplit = payload.split('**');
        
        return (
          <div key={idx} className="pl-4 py-1.5 border-l border-neutral-800 flex items-start gap-2 text-neutral-300">
            <span className={`inline-block w-1 h-1 rounded-full mt-1.5 ${isNeon ? 'bg-emerald-400' : 'bg-fuchsia-400'}`}></span>
            <span className="text-xs leading-relaxed">
              {boldSplit.map((piece, pieceIdx) => {
                if (pieceIdx % 2 === 1) {
                  return <strong key={pieceIdx} className="text-white font-semibold">{piece}</strong>;
                }
                return piece;
              })}
            </span>
          </div>
        );
      }

      // Default paragraph lines
      return (
        <p key={idx} className="text-xs text-neutral-400 leading-relaxed font-sans mb-2 pl-4">
          {trimmed}
        </p>
      );
    });
  };

  return (
    <div className={`p-6 rounded-2xl bg-black/40 backdrop-blur-xl border transition-all duration-300 ${
      isNeon 
        ? 'border-emerald-500/20 shadow-[0_4px_30px_rgba(16,185,129,0.03)]' 
        : 'border-fuchsia-100/10 shadow-[0_4px_30px_rgba(255,0,127,0.03)]'
    }`}>
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
            <Bot className={`w-5 h-5 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
            THEAi Hub Real-Time Assistant
          </h2>
          <p className="text-xs text-neutral-500 font-mono uppercase tracking-wider mt-0.5">
            Predictive Ledger Diagnostics & Smart Recourse Engine
          </p>
        </div>

        <button
          onClick={triggerDiagnostics}
          disabled={loading}
          className={`px-4 py-2 rounded-xl text-xs font-bold tracking-wider uppercase font-mono transition-all duration-300 flex items-center gap-2 cursor-pointer ${
            loading 
              ? 'bg-neutral-900 border border-neutral-800 text-neutral-500 cursor-not-allowed'
              : isNeon 
                ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500 hover:text-black hover:border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.1)]'
                : 'bg-fuchsia-500/10 border border-fuchsia-500/30 text-fuchsia-400 hover:bg-fuchsia-500 hover:text-white hover:border-fuchsia-500 shadow-[0_0_15px_rgba(240,46,170,0.1)]'
          }`}
        >
          <Sparkles className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Analyzing...' : 'Activate AI Diagnostician'}
        </button>
      </div>

      {/* Main container content */}
      <div className="min-h-[140px] flex flex-col justify-center relative overflow-hidden">
        <AnimatePresence mode="wait">
          {/* Default static message before activation */}
          {!loading && !insights && !error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center p-6 bg-neutral-900/40 border border-neutral-800/60 rounded-xl"
            >
              <Info className="w-8 h-8 text-neutral-600 mx-auto mb-3" />
              <p className="text-xs text-neutral-400 font-mono uppercase tracking-wider">
                Intelligence Engine Idle
              </p>
              <p className="text-[11px] text-neutral-500 max-w-md mx-auto mt-1 font-sans">
                Analyze your store's cash reserves, unpaid outstanding (udhari), and receive recommendations formatted dynamically.
              </p>
            </motion.div>
          )}

          {/* Core Loading Sequences Terminal */}
          {loading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="p-4 rounded-xl bg-black border border-neutral-900 font-mono text-[10px] space-y-1.5 text-neutral-400 h-[220px] overflow-y-auto"
            >
              <div className="flex items-center gap-2 text-emerald-400 border-b border-neutral-900 pb-1.5 mb-2 uppercase">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Inference Console Output
              </div>
              {logs.map((log, idx) => (
                <div key={idx} className="truncate flex items-center gap-1">
                  <span className="text-neutral-600">&gt;&gt;</span>
                  <span>{log}</span>
                </div>
              ))}
              <div className="pt-2 animate-pulse flex items-center gap-1.5 text-emerald-400 font-bold">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                QUERYING THEAi HUB GENERATIVE CORE APEX...
              </div>
            </motion.div>
          )}

          {/* AI Success Insights Result Card */}
          {!loading && insights && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="p-5 rounded-xl bg-[#070707] border border-neutral-900 text-xs text-neutral-300 font-mono relative"
            >
              {/* Badge indicating real Gemini inference vs simulation */}
              <div className="absolute top-4 right-4 text-[9px] px-2 py-0.5 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-400 flex items-center gap-1 font-mono uppercase">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Node: {source}
              </div>

              <div className="space-y-2 mt-4">
                {renderInsights(insights)}
              </div>
            </motion.div>
          )}

          {/* Error fallback card */}
          {!loading && error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-xs text-red-400 flex items-start gap-2.5"
            >
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold font-mono">⚡ ERR_CONNECTION_FAILED:</span> {error}
                <p className="text-[10px] text-red-500/80 mt-1">
                  Ensure the backend development server resides correctly on port 3000 to process inference queries.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* AI Ready architecture proof/footer */}
      <div className="mt-4 pt-4 border-t border-neutral-900/80 flex flex-col sm:flex-row items-center justify-between text-[10px] text-neutral-500 uppercase font-mono gap-2">
        <span>🤖 AI-Ready backend layout synchronized</span>
        <span className="flex items-center gap-1">
          Architected by <Heart className="w-3.5 h-3.5 text-red-500 fill-current ml-0.5" /> Harshvardhan Singh Lodhi
        </span>
      </div>
    </div>
  );
}
