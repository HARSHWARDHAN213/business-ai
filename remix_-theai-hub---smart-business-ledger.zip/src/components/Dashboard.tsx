/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Search, 
  Trash2, 
  CheckCircle, 
  AlertCircle, 
  RotateCcw, 
  Sparkles, 
  Grid,
  TrendingUp, 
  DollarSign, 
  LogOut, 
  Activity, 
  ArrowUpRight, 
  Users, 
  Download, 
  FileSpreadsheet,
  Settings,
  Flame,
  UserCheck,
  Eye,
  Printer,
  Image,
  Mail,
  Send,
  RefreshCw,
  Lock,
  Loader2,
  Check
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { Transaction, TransactionType, AppTheme, UserSession } from '../types';
import AISmartAssistant from './AISmartAssistant';
import BillingInvoice from './BillingInvoice';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, setDoc, doc, deleteDoc } from 'firebase/firestore';
import { connectGmail, getGmailToken, sendGmailMessage, listSentLedgerEmails, disconnectGmail } from '../gmail';
import { generateEmailHtmlForTransaction, generateEmailHtmlForStatement } from '../utils/emailTemplate';

interface DashboardProps {
  session: UserSession;
  theme: AppTheme;
  onChangeTheme: (theme: AppTheme) => void;
  onLogout: () => void;
}

export default function Dashboard({ session, theme, onChangeTheme, onLogout }: DashboardProps) {
  const isNeon = theme === 'NEON_MONOCHROME';
  
  // Premium System Unlock variables
  const [isPremiumUnlocked, setIsPremiumUnlocked] = useState<boolean>(() => {
    return localStorage.getItem('THEAI_HUB_PREMIUM_UNLOCKED') === 'true';
  });
  const [premiumRefCode, setPremiumRefCode] = useState('');
  const [unlockingPremium, setUnlockingPremium] = useState(false);
  const [unlockStatus, setUnlockStatus] = useState<string | null>(null);

  const handleUnlockPremium = async (uRefCode: string) => {
    if (!uRefCode.trim()) {
      alert("Please enter a valid reference UTR or Transaction code to verify.");
      return;
    }
    setUnlockingPremium(true);
    setUnlockStatus("Validating dynamic cryptographic transaction signature on database ledger...");
    await new Promise((resolve) => setTimeout(resolve, 1200));
    localStorage.setItem('THEAI_HUB_PREMIUM_UNLOCKED', 'true');
    setIsPremiumUnlocked(true);
    setUnlockStatus("LEDGER UNLOCKED: Premium security keys generated & active.");
    setUnlockingPremium(false);
  };

  const handleLockPremium = () => {
    localStorage.removeItem('THEAI_HUB_PREMIUM_UNLOCKED');
    setIsPremiumUnlocked(false);
    setPremiumRefCode('');
    setUnlockStatus(null);
  };
  
  // Gmail state Management variables
  const [gmailConnected, setGmailConnected] = useState(() => getGmailToken() !== null);
  const [gmailLoading, setGmailLoading] = useState(false);
  const [sentLogs, setSentLogs] = useState<any[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);
  const [sendingEmailId, setSendingEmailId] = useState<string | null>(null);
  const [custEmailInputs, setCustEmailInputs] = useState<Record<string, string>>({});

  const handleConnectGmail = async () => {
    setGmailLoading(true);
    try {
      await connectGmail();
      setGmailConnected(true);
    } catch (err: any) {
      alert(`Gmail Connection Protocol Denied: ${err.message || err}`);
    } finally {
      setGmailLoading(false);
    }
  };

  const handleDisconnectGmail = () => {
    disconnectGmail();
    setGmailConnected(false);
    setSentLogs([]);
  };

  const loadGmailLogs = async () => {
    if (getGmailToken()) {
      setLogsLoading(true);
      try {
        const logs = await listSentLedgerEmails();
        setSentLogs(logs);
      } catch (err) {
        console.error("Failed to fetch Gmail sent metadata:", err);
      } finally {
        setLogsLoading(false);
      }
    }
  };

  const [recipientEmail, setRecipientEmail] = useState('');
  const [emailSending, setEmailSending] = useState(false);
  const [emailStatus, setEmailStatus] = useState<string | null>(null);

  const handleSendTxnEmail = async (t: Transaction, toEmail: string) => {
    if (!toEmail || !toEmail.includes('@')) {
      alert("Invalid Recipient Address: Please specify a valid destination email.");
      return;
    }
    
    setEmailSending(true);
    setEmailStatus("Transmitting cryptographic invoice payload...");
    try {
      const subject = `THEAi Hub - Bill Invoice Receipt [Ref: ${t.billId}]` + (session.shopName ? ` | ${session.shopName}` : '');
      const htmlContent = generateEmailHtmlForTransaction(t, session.shopName, session.username);
      
      await sendGmailMessage(toEmail, subject, htmlContent);
      setEmailStatus("DISPATCHED: Invoice receipt successfully broadcasted!");
      
      // Auto-reload sync list
      setTimeout(() => {
        loadGmailLogs();
      }, 500);
    } catch (err: any) {
      console.error(err);
      setEmailStatus(`REJECTED: ${err.message || err}`);
    } finally {
      setEmailSending(false);
    }
  };

  const handleSendStatementEmail = async (customerName: string, customerData: any, toEmail: string) => {
    if (!toEmail || !toEmail.includes('@')) {
      alert("Invalid Recipient Address: Please specify a valid destination email.");
      return;
    }
    
    setEmailSending(true);
    setEmailStatus("Transmitting credit statement chronology...");
    try {
      const subject = `THEAi Hub - Audited Credit Statement [Client: ${customerName}]` + (session.shopName ? ` | ${session.shopName}` : '');
      const htmlContent = generateEmailHtmlForStatement(customerName, customerData, session.shopName, session.username);
      
      await sendGmailMessage(toEmail, subject, htmlContent);
      setEmailStatus("DISPATCHED: Credit statement successfully broadcasted!");
      
      // Auto-reload sync list
      setTimeout(() => {
        loadGmailLogs();
      }, 500);
    } catch (err: any) {
      console.error(err);
      setEmailStatus(`REJECTED: ${err.message || err}`);
    } finally {
      setEmailSending(false);
    }
  };

  useEffect(() => {
    if (gmailConnected) {
      loadGmailLogs();
    } else {
      setSentLogs([]);
    }
  }, [gmailConnected]);

  // Dynamic timestamp
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Core Transactions list state, backed by localStorage for offline sync!
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('THEAI_HUB_LEDGER_TXNS');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved transactions, resetting.', e);
      }
    }
    // Return stunning initial seed data to give the portal immediate financial life
    return [
      {
        id: 'txn-rakesh-due',
        billId: 'THEAI-2026-6101',
        customerName: 'Rakesh',
        customerPhone: '+91 9988776655',
        amount: 6000,
        type: 'DUE',
        description: 'Outstanding item invoice logged for dynamic logic units',
        date: new Date(Date.now() - 3600000 * 12).toISOString(),
        items: [{ name: 'Dynamic High-Perf Logic Board', quantity: 1, price: 6000 }]
      },
      {
        id: 'txn-rakesh-rec',
        billId: 'THEAI-2026-6102',
        customerName: 'Rakesh',
        customerPhone: '+91 9988776655',
        amount: 2000,
        type: 'RECOVERY',
        description: 'Partial cashier payment received - outstanding balance tracked',
        date: new Date(Date.now() - 3600000 * 2).toISOString(),
        items: [{ name: 'Cash Advance Installed Payment', quantity: 1, price: 2000 }]
      },
      {
        id: 'txn-1',
        billId: 'THEAI-2026-9481',
        customerName: 'Shubham Verma',
        customerPhone: '+91 9111452932',
        amount: 8500,
        type: 'PAID',
        description: 'Settled bill for dynamic graphics card replacement unit',
        date: new Date(Date.now() - 3600000 * 48).toISOString(),
        items: [{ name: 'Graphics Unit V2', quantity: 1, price: 8500 }]
      },
      {
        id: 'txn-2',
        billId: 'THEAI-2026-2184',
        customerName: 'Aman Dixit',
        customerPhone: '+91 8871032145',
        amount: 4200,
        type: 'DUE',
        description: 'Outstanding udhari for server power supplies',
        date: new Date(Date.now() - 3600000 * 24).toISOString(),
        items: [{ name: 'Smart Power Supply Unit', quantity: 2, price: 2100 }]
      },
      {
        id: 'txn-3',
        billId: 'THEAI-2026-7731',
        customerName: 'Ramesh Lodhi',
        customerPhone: '+91 7000512849',
        amount: 2500,
        type: 'RECOVERY',
        description: 'Partial dues recovery of previous outstanding ledger',
        date: new Date(Date.now() - 3600000 * 4).toISOString(),
        items: [{ name: 'Previous Debt Installment', quantity: 1, price: 2500 }]
      }
    ];
  });

  // Real-time synchronization from Firestore
  useEffect(() => {
    const currentUser = auth.currentUser;
    if (currentUser && session.email) {
      const q = query(
        collection(db, 'transactions'),
        where('userEmail', '==', session.email)
      );

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const list: Transaction[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            list.push({
              id: docSnap.id,
              billId: data.billId,
              customerName: data.customerName,
              customerPhone: data.customerPhone || undefined,
              amount: data.amount,
              type: data.type,
              description: data.description,
              date: data.date,
              items: data.items || []
            });
          });
          // Sort descending by date
          list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          setTransactions(list);
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'transactions');
        }
      );

      return () => unsubscribe();
    }
  }, [session.email]);

  // Keep localStorage sync as offline fallback
  useEffect(() => {
    if (!auth.currentUser) {
      localStorage.setItem('THEAI_HUB_LEDGER_TXNS', JSON.stringify(transactions));
    }
  }, [transactions]);

  // Tab controls for Registry: 'TRANSACTIONS' vs 'CUSTOMER_ACCOUNTS'
  const [activeRegistryTab, setActiveRegistryTab] = useState<'TRANSACTIONS' | 'CUSTOMER_ACCOUNTS'>('TRANSACTIONS');

  // Compute customer-wise balances and historical transactions timelines dynamically
  const customerLedgers = React.useMemo(() => {
    const map: Record<string, {
      name: string;
      totalBilled: number;
      totalPaid: number;
      phone?: string;
      lastActive: string;
      transactions: Transaction[];
    }> = {};

    // Process from oldest to newest to compile balance timeline mathematically correct
    const sorted = [...transactions].reverse();

    sorted.forEach((t) => {
      const key = t.customerName.trim().toLowerCase();
      if (!map[key]) {
        map[key] = {
          name: t.customerName.trim(),
          totalBilled: 0,
          totalPaid: 0,
          phone: t.customerPhone,
          lastActive: t.date,
          transactions: []
        };
      }
      
      const client = map[key];
      client.transactions.unshift(t); // Keep newest on top
      if (t.customerPhone) {
        client.phone = t.customerPhone;
      }
      if (new Date(t.date) > new Date(client.lastActive)) {
        client.lastActive = t.date;
      }

      if (t.type === 'DUE') {
        client.totalBilled += t.amount;
      } else if (t.type === 'RECOVERY') {
        client.totalPaid += t.amount;
      } else if (t.type === 'PAID') {
        client.totalBilled += t.amount;
        client.totalPaid += t.amount;
      }
    });

    return Object.values(map).map(c => ({
      ...c,
      balance: Math.max(0, c.totalBilled - c.totalPaid)
    }));
  }, [transactions]);

  // One-click print-to-PDF compiler for individual transaction bill
  const downloadSingleBill = (t: Transaction) => {
    const isNeonTheme = theme === 'NEON_MONOCHROME';
    const accentColor = isNeonTheme ? '#10b981' : '#f43f5e';
    const accentText = isNeonTheme ? 'text-emerald-400' : 'text-fuchsia-400';
    
    const itemsRows = t.items && t.items.length > 0 
      ? t.items.map(item => `
        <tr style="border-bottom: 1px solid #1f1f23;">
          <td style="padding: 12px 10px; text-align: left; font-weight: 500; font-family: sans-serif;">${item.name}</td>
          <td style="padding: 12px 10px; text-align: center; font-family: monospace;">${item.quantity}</td>
          <td style="padding: 12px 10px; text-align: right; font-family: monospace;">₹${item.price.toLocaleString()}</td>
          <td style="padding: 12px 10px; text-align: right; font-weight: bold; color: #fff; font-family: monospace;">₹${(item.quantity * item.price).toLocaleString()}</td>
        </tr>
      `).join('')
      : `
        <tr style="border-bottom: 1px solid #1f1f23;">
          <td style="padding: 12px 10px; text-align: left; font-family: sans-serif;">${t.description || 'Ledger transaction detail'}</td>
          <td style="padding: 12px 10px; text-align: center; font-family: monospace;">1</td>
          <td style="padding: 12px 10px; text-align: right; font-family: monospace;">₹${t.amount.toLocaleString()}</td>
          <td style="padding: 12px 10px; text-align: right; font-weight: bold; color: #fff; font-family: monospace;">₹${t.amount.toLocaleString()}</td>
        </tr>
      `;

    const calculatedSub = t.items && t.items.length > 0 
      ? t.items.reduce((sum, item) => sum + (item.quantity * item.price), 0)
      : t.amount;
    const isBilledInvoice = t.items && t.items.length > 0;
    const calculatedTax = isBilledInvoice ? Math.round(calculatedSub * 0.05) : 0;
    const calculatedGrand = isBilledInvoice ? (calculatedSub + calculatedTax) : t.amount;

    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>THEAi Hub Invoice - ${t.billId}</title>
  <style>
    body {
      background-color: #030303;
      color: #e2e8f0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      margin: 0;
      padding: 40px 20px;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .invoice-card {
      width: 100%;
      max-width: 600px;
      background-color: #0c0c0e;
      border: 1px solid ${accentColor}40;
      box-shadow: 0 0 30px ${accentColor}15;
      border-radius: 16px;
      padding: 30px;
      box-sizing: border-box;
      position: relative;
    }
    .top-bar {
      height: 4px;
      background: linear-gradient(90deg, ${accentColor}, #06b6d4);
      margin-top: -30px;
      margin-left: -30px;
      margin-right: -30px;
      border-top-left-radius: 15px;
      border-top-right-radius: 15px;
      margin-bottom: 30px;
    }
    .branding {
      text-align: center;
      margin-bottom: 25px;
    }
    .logo-main {
      font-size: 25px;
      font-weight: 800;
      letter-spacing: -0.5px;
      color: #fff;
    }
    .logo-main span {
      color: ${accentColor};
    }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 10px;
      font-weight: bold;
      text-transform: uppercase;
      margin-top: 8px;
      background-color: ${t.type === 'PAID' ? 'rgba(16,185,129,0.15)' : t.type === 'DUE' ? 'rgba(239,68,68,0.15)' : 'rgba(6,182,212,0.15)'};
      color: ${t.type === 'PAID' ? '#10b981' : t.type === 'DUE' ? '#f87171' : '#22d3ee'};
      border: 1px solid ${t.type === 'PAID' ? 'rgba(16,185,129,0.3)' : t.type === 'DUE' ? 'rgba(239,68,68,0.3)' : 'rgba(6,182,212,0.3)'};
    }
    .grid-meta {
      display: grid;
      grid-template-cols: 1fr 1fr;
      gap: 15px;
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 1px dashed #222;
      font-size: 11px;
      color: #777;
    }
    .meta-val {
      color: #fff;
      font-weight: 600;
      margin-top: 3px;
      font-size: 13px;
    }
    .table-bill {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      color: #bbb;
      margin-bottom: 25px;
    }
    .table-bill th {
      border-bottom: 1px solid #333;
      padding-bottom: 8px;
      color: #666;
      text-transform: uppercase;
      font-size: 10px;
      letter-spacing: 1px;
    }
    .totals-area {
      margin-top: 15px;
      padding-top: 15px;
      border-top: 1px dashed #222;
      font-size: 12px;
      color: #777;
    }
    .row-total {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
    }
    .grand-total {
      display: flex;
      justify-content: space-between;
      font-size: 16px;
      font-weight: 800;
      color: #fff;
      border-top: 1px solid #333;
      padding-top: 15px;
      margin-top: 12px;
    }
    .grand-total span {
      color: ${accentColor};
    }
    .stamp {
      text-align: center;
      margin-top: 35px;
      font-size: 9px;
      color: #444;
      text-transform: uppercase;
      letter-spacing: 1px;
      line-height: 1.5;
    }
    .p-btn {
      display: block;
      width: 100%;
      padding: 12px;
      border: none;
      background: ${accentColor};
      color: ${isNeonTheme ? '#030303' : '#ffffff'};
      font-weight: bold;
      font-size: 13px;
      border-radius: 8px;
      margin-top: 25px;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: opacity 0.2s;
    }
    .p-btn:hover {
      opacity: 0.9;
    }
    @media print {
      .p-btn { display: none; }
      body { background-color: #fff; color: #000; padding: 0; }
      .invoice-card { border: none; box-shadow: none; background: #fff; padding: 0; max-width: 100%; }
      .meta-val, .grand-total { color: #000; }
      th, .totals-area, .grand-total { border-color: #ccc; }
      td, th { color: #333; }
    }
  </style>
</head>
<body>
  <div class="invoice-card">
    <div class="top-bar"></div>
    
    <div class="branding">
      <div class="logo-main">THE<span>Ai Hub</span></div>
      <div style="font-size: 9px; color: #666; text-transform: uppercase; margin-top: 2px; letter-spacing: 1px;">
        ${session.shopName}
      </div>
      <div style="font-size: 8px; color: #555; margin-top: 4px;">
        Operator Name: ${session.username}
      </div>
      <div><span class="badge">${t.type}</span></div>
    </div>

    <div class="grid-meta">
      <div>
        <div>BILL INVOICE ID</div>
        <div class="meta-val">${t.billId}</div>
      </div>
      <div style="text-align: right;">
        <div>DATE TIME</div>
        <div class="meta-val">${new Date(t.date).toLocaleString()}</div>
      </div>
      <div style="margin-top: 10px;">
        <div>CLIENT NAME</div>
        <div class="meta-val" style="text-transform: uppercase;">${t.customerName}</div>
      </div>
      <div style="text-align: right; margin-top: 10px;">
        <div>CLIENT MOBILE</div>
        <div class="meta-val">${t.customerPhone || 'NOT IN ARCHIVES'}</div>
      </div>
    </div>

    <table class="table-bill">
      <thead>
        <tr>
          <th style="text-align: left;">SPECIFICATION</th>
          <th style="width: 50px; text-align: center;">QTY</th>
          <th style="width: 100px; text-align: right;">PRICE</th>
          <th style="width: 100px; text-align: right;">TOTAL</th>
        </tr>
      </thead>
      <tbody>
        ${itemsRows}
      </tbody>
    </table>

    <div class="totals-area">
      <div class="row-total">
        <span>SUBTOTAL COMPILATION:</span>
        <span style="color: #fff; font-weight: 600;">₹${calculatedSub.toLocaleString()}</span>
      </div>
      <div class="row-total">
        <span>CONVENIENCE TAX (5%):</span>
        <span style="color: #fff; font-weight: 600;">₹${calculatedTax.toLocaleString()}</span>
      </div>
      <div class="row-total">
        <span>CLASSIFIED PAYMENT TYPE:</span>
        <span style="color: #fff; font-weight: 600; text-transform: uppercase;">${t.type}</span>
      </div>
      <div class="grand-total">
        <span>GRAND TOTAL REVENUE:</span>
        <span>₹${calculatedGrand.toLocaleString()}</span>
      </div>
    </div>

    <div class="stamp">
      TRANSACTION TOKEN &bull; ${t.id.toUpperCase()}<br/>
      DEVELOPED FOR THEAI HUB CORE ENGINE BY HARSHVARDHAN SINGH LODHI<br/>
      SECURED LOCAL DIGITAL COGNITION SYNC MATRIX
    </div>

    <button class="p-btn" onclick="window.print()">Print / Save PDF</button>
  </div>
</body>
</html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const triggerLink = document.createElement('a');
    triggerLink.href = url;
    triggerLink.download = `THEAI_Bill_${t.billId}_${t.customerName.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(triggerLink);
    triggerLink.click();
    document.body.removeChild(triggerLink);
    URL.revokeObjectURL(url);
  };

  // One-click print-to-PDF compiler for customer total outstanding statements (showing total due, total paid, and baki pending)
  const downloadCustomerStatement = (customerName: string, customerData: any) => {
    const isNeonTheme = theme === 'NEON_MONOCHROME';
    const accentColor = isNeonTheme ? '#10b981' : '#f43f5e';
    
    const txnRows = customerData.transactions.map((t: Transaction) => {
      let typeBadgeHex = 'rgba(16,185,129,0.15)';
      let typeTextHex = '#10b981';
      if (t.type === 'DUE') {
        typeBadgeHex = 'rgba(239,68,68,0.15)';
        typeTextHex = '#f87171';
      } else if (t.type === 'RECOVERY') {
        typeBadgeHex = 'rgba(6,182,212,0.15)';
        typeTextHex = '#22d3ee';
      }

      return `
        <tr style="border-bottom: 1px solid #1c1c1f;">
          <td style="padding: 12px 10px; font-weight: 500; font-family: monospace; font-size: 11px;">${new Date(t.date).toLocaleDateString()}</td>
          <td style="padding: 12px 10px; font-weight: bold; font-family: monospace; font-size: 11px; color:#fff;">${t.billId}</td>
          <td style="padding: 12px 10px;">
            <span style="display:inline-block; padding: 2px 6px; border-radius: 4px; font-size: 9px; font-weight:bold; text-transform:uppercase; background-color:${typeBadgeHex}; color:${typeTextHex};">
              ${t.type}
            </span>
          </td>
          <td style="padding: 12px 10px; font-size: 11px; font-family: sans-serif;">${t.description || 'Ledger transaction'}</td>
          <td style="padding: 12px 10px; text-align: right; font-weight: bold; font-family: monospace; font-size: 11px; color: #fff;">
            ₹${t.amount.toLocaleString()}
          </td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>THEAi Hub Ledger Statement - ${customerName}</title>
  <style>
    body {
      background-color: #030303;
      color: #e2e8f0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      margin: 0;
      padding: 40px 20px;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .statement-card {
      width: 100%;
      max-width: 750px;
      background-color: #0c0c0e;
      border: 1px solid ${accentColor}33;
      box-shadow: 0 0 35px ${accentColor}10;
      border-radius: 16px;
      padding: 35px;
      box-sizing: border-box;
      position: relative;
    }
    .top-strip {
      height: 4px;
      background: linear-gradient(90deg, ${accentColor}, #06b6d4);
      margin-top: -35px;
      margin-left: -35px;
      margin-right: -35px;
      border-top-left-radius: 15px;
      border-top-right-radius: 15px;
      margin-bottom: 30px;
    }
    .branding {
      text-align: center;
      margin-bottom: 30px;
    }
    .logo {
      font-size: 26px;
      font-weight: 800;
      letter-spacing: -1px;
      color: #fff;
    }
    .logo span {
      color: ${accentColor};
    }
    .client-header {
      background-color: #111113;
      border: 1px solid #1f1f23;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 35px;
      display: grid;
      grid-template-cols: 1.5fr 1fr;
      gap: 15px;
      font-size: 12px;
    }
    .header-title {
      font-size: 10px;
      color: #555;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 4px;
    }
    .header-val {
      font-size: 16px;
      font-weight: bold;
      color: #fff;
    }
    .summary-grid {
      display: grid;
      grid-template-cols: 1fr 1fr 1fr;
      gap: 15px;
      margin-bottom: 35px;
    }
    .summary-box {
      background-color: #111113;
      border: 1px solid #1f1f23;
      border-radius: 12px;
      padding: 15px;
    }
    .summary-box-title {
      font-size: 9px;
      color: #555;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 5px;
    }
    .summary-box-num {
      font-size: 18px;
      font-weight: bold;
      font-family: monospace;
    }
    .table-spec {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      color: #aaa;
      margin-top: 15px;
      margin-bottom: 30px;
    }
    .table-spec th {
      border-bottom: 1px solid #333;
      padding: 10px;
      color: #555;
      text-transform: uppercase;
      font-size: 9px;
      letter-spacing: 1px;
      background-color: #111113;
    }
    .stamp-footer {
      text-align: center;
      margin-top: 40px;
      font-size: 9px;
      color: #444;
      text-transform: uppercase;
      letter-spacing: 1px;
      line-height: 1.6;
    }
    .p-btn-statement {
      display: block;
      width: 100%;
      padding: 12px;
      border: none;
      background: ${accentColor};
      color: ${isNeonTheme ? '#030303' : '#ffffff'};
      font-weight: bold;
      font-size: 13px;
      border-radius: 8px;
      margin-top: 25px;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: opacity 0.2s;
    }
    @media print {
      .p-btn-statement { display: none; }
      body { background-color: #fff; color: #000; padding: 0; }
      .statement-card { border: none; box-shadow: none; background: #fff; padding: 0; max-width: 100%; }
      .client-header, .summary-box, th { background-color: #f8f9fa !important; border-color: #ddd !important; }
      .header-val, .summary-box-num, td, th { color: #000 !important; }
      th, .table-spec { border-color: #ccc; }
      td, th { color: #333; }
    }
  </style>
</head>
<body>
  <div class="statement-card">
    <div class="top-strip"></div>
    
    <div class="branding">
      <div class="logo">THE<span>Ai Hub</span></div>
      <div style="font-size: 9px; color: #666; text-transform: uppercase; margin-top: 2px; letter-spacing: 2px;">
        AUDITED CUSTOMER DUES STATEMENT
      </div>
      <div style="font-size: 8px; color: #444; margin-top: 4px;">
        Originating Node: ${session.shopName} | Operator Signature: ${session.username}
      </div>
    </div>

    <div class="client-header">
      <div>
        <div class="header-title">Customer Account Identity</div>
        <div class="header-val" style="text-transform: uppercase;">${customerName}</div>
        <div style="font-size:10px; color:#777; margin-top:5px;">Contact Phone: ${customerData.phone || 'NOT FOUND IN ARCHIVES'}</div>
      </div>
      <div style="text-align: right;">
        <div class="header-title">Statement Compilation Date</div>
        <div class="header-val" style="font-size:12px; font-family:monospace;">${new Date().toLocaleDateString()}</div>
        <div style="font-size: 10px; color: ${customerData.balance > 0 ? '#ef4444' : '#10b981'}; font-weight:bold; text-transform:uppercase; margin-top:5px;">
          ${customerData.balance > 0 ? 'Status: Overdue Dues Balance' : 'Status: Fully Cleared Ledger'}
        </div>
      </div>
    </div>

    <div class="summary-grid">
      <div class="summary-box">
        <div class="summary-box-title">Total Purchases / Dues</div>
        <div class="summary-box-num" style="color: #fff;">₹${customerData.totalBilled.toLocaleString()}</div>
      </div>
      <div class="summary-box">
        <div class="summary-box-title">Total Payments Cleared</div>
        <div class="summary-box-num" style="color: #10b981;">₹${customerData.totalPaid.toLocaleString()}</div>
      </div>
      <div class="summary-box" style="border: 1px solid ${customerData.balance > 0 ? 'rgba(239,68,68,0.4)' : 'rgba(16,185,129,0.4)'}">
        <div class="summary-box-title" style="color: ${customerData.balance > 0 ? '#f87171' : '#10b981'}">Net Pending Balance</div>
        <div class="summary-box-num" style="color: ${customerData.balance > 0 ? '#f87171' : '#10b981'};">₹${customerData.balance.toLocaleString()}</div>
      </div>
    </div>

    <h4 style="font-size: 11px; margin-top:20px; font-weight:bold; text-transform:uppercase; letter-spacing:1.5px; color:#fff;">
      Itemized Transaction Chronology Log
    </h4>
    <table class="table-spec">
      <thead>
        <tr>
          <th style="text-align: left; width: 90px;">DATE</th>
          <th style="text-align: left; width: 140px;">BILL INVOICE ID</th>
          <th style="text-align: left; width: 90px;">TYPE</th>
          <th style="text-align: left;">MEMO / DESCRIPTION</th>
          <th style="text-align: right; width: 120px;">AMOUNT</th>
        </tr>
      </thead>
      <tbody>
        ${txnRows}
      </tbody>
    </table>

    <div class="stamp-footer">
      STATEMENT VERIFICATION MATRIX &bull; INTEGRATED DIGITAL LEDGER SYSTEMS<br/>
      ORIGINATING THEAI HUB ARCHITECTURE FOUNDED BY HARSHVARDHAN SINGH LODHI<br/>
      AUTO-COMPILED SECURE DIGITAL LEDGER TOKEN SYNC
    </div>

    <button class="p-btn-statement" onclick="window.print()">Print / Save PDF</button>
  </div>
</body>
</html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const triggerLink = document.createElement('a');
    triggerLink.href = url;
    triggerLink.download = `THEAI_Statement_Pending_Dues_${customerName.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(triggerLink);
    triggerLink.click();
    document.body.removeChild(triggerLink);
    URL.revokeObjectURL(url);
  };

  // Pre-fill manual input with selected customer for fast payments clearance
  const handleSelectCustomerForRecovery = (customerName: string, customerPhone?: string) => {
    setManualName(customerName);
    if (customerPhone) {
      setManualPhone(customerPhone);
    }
    setManualType('RECOVERY');
    setManualDesc(`Clearance payment received from client ${customerName}`);
    
    // Smooth scroll down to quick ledger entry form wrapper
    const formElement = document.getElementById('manual-ledger-form-card');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Modal views
  const [showInvoicer, setShowInvoicer] = useState(false);
  const [selectedPreviewTxn, setSelectedPreviewTxn] = useState<Transaction | null>(null);
  const [selectedPreviewStatement, setSelectedPreviewStatement] = useState<{name: string, data: any} | null>(null);

  // Reset modal email state on open/close transitions
  useEffect(() => {
    if (selectedPreviewTxn) {
      setRecipientEmail('');
      setEmailStatus(null);
    }
  }, [selectedPreviewTxn]);

  useEffect(() => {
    if (selectedPreviewStatement) {
      setRecipientEmail('');
      setEmailStatus(null);
    }
  }, [selectedPreviewStatement]);

  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | TransactionType>('ALL');

  // Direct manual fast transaction inputs auto-saved in draft
  const [quickDraft, setQuickDraft] = useState<any>(() => {
    const saved = localStorage.getItem('THEAI_HUB_QUICK_LEDGER_DRAFT');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved quick ledger draft', e);
      }
    }
    return null;
  });

  const [manualName, setManualName] = useState(() => quickDraft?.manualName ?? '');
  const [manualPhone, setManualPhone] = useState(() => quickDraft?.manualPhone ?? '');
  const [manualAmt, setManualAmt] = useState(() => quickDraft?.manualAmt ?? '');
  const [manualType, setManualType] = useState<TransactionType>(() => quickDraft?.manualType ?? 'PAID');
  const [manualDesc, setManualDesc] = useState(() => quickDraft?.manualDesc ?? '');

  // Auto-save the manual inputs to localStorage in real time
  useEffect(() => {
    const draftData = {
      manualName,
      manualPhone,
      manualAmt,
      manualType,
      manualDesc
    };
    localStorage.setItem('THEAI_HUB_QUICK_LEDGER_DRAFT', JSON.stringify(draftData));
  }, [manualName, manualPhone, manualAmt, manualType, manualDesc]);

  const handleAddManualTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualName.trim() || !manualAmt || Number(manualAmt) <= 0) {
      alert('Kindly fill in the valid customer ID and a numeric amount.');
      return;
    }

    const formatNum = Math.floor(1000 + Math.random() * 9000);
    const generatedBillId = `THEAI-${new Date().getFullYear()}-${formatNum}`;
    const txnId = `txn-${Date.now()}`;

    const newTxn: Transaction = {
      id: txnId,
      billId: generatedBillId,
      customerName: manualName.trim(),
      customerPhone: manualPhone.trim() || undefined,
      amount: Number(manualAmt),
      type: manualType,
      description: manualDesc.trim() || `${manualType} entry logged manually`,
      date: new Date().toISOString(),
      items: [{ name: manualDesc.trim() || 'Custom Ledger Product', quantity: 1, price: Number(manualAmt) }]
    };

    if (auth.currentUser && session.email) {
      try {
        const docRef = doc(db, 'transactions', txnId);
        await setDoc(docRef, { ...newTxn, userEmail: session.email });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `transactions/${txnId}`);
      }
    } else {
      setTransactions((prev) => [newTxn, ...prev]);
    }
    
    // Reset manual input fields
    setManualName('');
    setManualPhone('');
    setManualAmt('');
    setManualDesc('');
    localStorage.removeItem('THEAI_HUB_QUICK_LEDGER_DRAFT');
  };

  const handleSaveInvoiceFromModal = async (invoiceData: Omit<Transaction, 'id' | 'date'>) => {
    const txnId = `txn-${Date.now()}`;
    const freshTxn: Transaction = {
      ...invoiceData,
      id: txnId,
      date: new Date().toISOString()
    };

    if (auth.currentUser && session.email) {
      try {
        const docRef = doc(db, 'transactions', txnId);
        await setDoc(docRef, { ...freshTxn, userEmail: session.email });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `transactions/${txnId}`);
      }
    } else {
      setTransactions((prev) => [freshTxn, ...prev]);
    }
    setShowInvoicer(false);
  };

  const handleDeleteTransaction = async (id: string) => {
    if (confirm('Permanently wipe this ledger block? This updates real-time caches.')) {
      if (auth.currentUser && session.email) {
        try {
          const docRef = doc(db, 'transactions', id);
          await deleteDoc(docRef);
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, `transactions/${id}`);
        }
      } else {
        setTransactions((prev) => prev.filter((t) => t.id !== id));
      }
    }
  };

  const handleResetLedger = async () => {
    if (confirm('Are you absolutely sure you wish to rebuild the local ledger cache to zero?')) {
      if (auth.currentUser && session.email) {
        try {
          for (const t of transactions) {
            const docRef = doc(db, 'transactions', t.id);
            await deleteDoc(docRef);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, `transactions`);
        }
      } else {
        setTransactions([]);
      }
    }
  };

  // Live Analytical Aggregations (Dues-to-Revenue index, amounts, total cleared)
  const paidCount = transactions.filter((t) => t.type === 'PAID');
  const dueCount = transactions.filter((t) => t.type === 'DUE');
  const recoveryCount = transactions.filter((t) => t.type === 'RECOVERY');

  const totalRevenue = paidCount.reduce((sum, t) => sum + t.amount, 0);
  const totalDues = dueCount.reduce((sum, t) => sum + t.amount, 0);
  const totalRecovered = recoveryCount.reduce((sum, t) => sum + t.amount, 0);

  // Net Pending Dues outstanding calculation
  // (Actual outstanding = Total Due entries - Total Recovered entries across customers)
  const netPendingDues = Math.max(0, totalDues - totalRecovered);

  // Filtered entries computed cleanly
  const filteredTxns = transactions.filter((t) => {
    const matchesSearch = t.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.billId.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (t.description && t.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType = typeFilter === 'ALL' || t.type === typeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen cyber-grid py-6 px-4 md:px-8 bg-[#020202]">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Interactive Top Ribbon Header */}
        <header className={`p-4 rounded-2xl bg-black/60 backdrop-blur-md border flex flex-col md:flex-row items-center justify-between gap-4 transition-colors duration-500 ${
          isNeon ? 'border-emerald-500/20 shadow-[0_4px_20px_rgba(16,185,129,0.02)]' : 'border-fuchsia-500/10 shadow-[0_4px_25px_rgba(236,72,153,0.02)]'
        }`}>
          {/* Shop branding */}
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl border flex items-center justify-center ${
              isNeon ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-fuchsia-950/20 border-fuchsia-500/30'
            }`}>
              <Grid className={`w-5 h-5 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight font-sans">
                {session.shopName}
              </h1>
              <p className="text-[10px] text-neutral-500 font-mono tracking-widest uppercase flex items-center gap-2">
                <span>SYSTEM ACTIVE</span>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                <span>UTC: {currentTime}</span>
              </p>
            </div>
          </div>

          {/* Controls & Switchers alignment */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Premium / Standard system badge */}
            <div className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 border max-sm:w-full ${
              isPremiumUnlocked 
                ? 'bg-amber-950/20 border-amber-500/30 text-amber-400' 
                : 'bg-red-950/20 border-red-500/30 text-red-400'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isPremiumUnlocked ? 'bg-amber-400 animate-pulse' : 'bg-red-400'}`}></span>
              <span>{isPremiumUnlocked ? '👑 VIP UNLOCKED' : '🔒 STANDARD MODE'}</span>
            </div>

            {/* Operator signature showcase */}
            <div className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-300 flex items-center gap-1.5 max-sm:w-full">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Owner: {session.username}</span>
            </div>

            {/* Themes button toggle */}
            <div className="flex rounded-lg bg-neutral-900 p-1 border border-neutral-800 self-stretch">
              <button
                onClick={() => onChangeTheme('NEON_MONOCHROME')}
                className={`text-[10px] uppercase font-mono tracking-wider font-bold py-1 px-3.5 rounded cursor-pointer transition-all ${
                  isNeon ? 'bg-emerald-500 text-black shadow-md' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Neon Mono
              </button>
              <button
                onClick={() => onChangeTheme('MIDNIGHT_VELOCITY')}
                className={`text-[10px] uppercase font-mono tracking-wider font-bold py-1 px-3.5 rounded cursor-pointer transition-all ${
                  !isNeon ? 'bg-fuchsia-500 text-white shadow-md' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Midnight Velocity
              </button>
            </div>

            {/* Logout actions */}
            <button
              onClick={onLogout}
              className="py-1.5 px-3 rounded-lg bg-red-950/30 hover:bg-red-900/30 border border-red-900/40 hover:border-red-700/60 text-red-400 text-xs font-mono hover:text-red-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Exit
            </button>
          </div>
        </header>

        {/* Real-time Metric Dashboards Row */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Total Revenue Card */}
          <div className={`p-6 rounded-2xl bg-black border relative overflow-hidden transition-all duration-300 ${
            isNeon 
              ? 'border-emerald-500/20' 
              : 'border-neutral-900 hover:border-neutral-800 shadow-[0_4px_25px_rgba(34,197,94,0.02)]'
          }`}>
            <div className="absolute top-1/2 right-4 -translate-y-1/2 opacity-5 pointer-events-none">
              <TrendingUp className="w-24 h-24 text-emerald-400" />
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] text-neutral-500 font-mono tracking-wider uppercase">
                Direct Revenue (Paid List)
              </span>
              <span className="p-1 px-2 rounded bg-emerald-900/20 text-emerald-400 border border-emerald-500/10 text-[9px] font-mono">
                Settled In Cash
              </span>
            </div>
            <h2 className="text-3xl font-bold text-white tracking-tight flex items-baseline gap-1 font-mono">
              <span className="text-xl text-emerald-400 font-normal">₹</span>
              {totalRevenue.toLocaleString()}
            </h2>
            <div className="mt-3 text-[10px] text-neutral-400 font-mono flex items-center gap-1">
              <span className="text-emerald-400 font-bold">{paidCount.length}</span> settled invoices synchronized.
            </div>
          </div>

          {/* Pending Dues Outstanding Card */}
          <div className={`p-6 rounded-2xl bg-black border relative overflow-hidden transition-all duration-300 ${
            isNeon 
              ? 'border-red-500/10' 
              : 'border-neutral-900 hover:border-neutral-800 shadow-[0_4px_25px_rgba(239,68,68,0.02)]'
          }`}>
            <div className="absolute top-1/2 right-4 -translate-y-1/2 opacity-5 pointer-events-none">
              <AlertCircle className="w-24 h-24 text-rose-500" />
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] text-neutral-500 font-mono tracking-wider uppercase">
                Pending Dues / Udhari
              </span>
              <span className="p-1 px-2 rounded bg-red-900/20 text-red-500 border border-red-500/10 text-[9px] font-mono">
                Overdue Credit
              </span>
            </div>
            <h2 className="text-3xl font-bold text-white tracking-tight flex items-baseline gap-1 font-mono">
              <span className="text-xl text-red-400 font-normal">₹</span>
              {netPendingDues.toLocaleString()}
            </h2>
            <div className="mt-3 text-[10px] text-neutral-400 font-mono flex items-center justify-between">
              <span>Outstanding dues: <strong className="text-red-400 font-bold">{dueCount.length}</strong> blockages</span>
              <span className="text-red-500 text-[9px]">Requires Attention</span>
            </div>
          </div>

          {/* Total Recovered Card */}
          <div className={`p-6 rounded-2xl bg-black border relative overflow-hidden transition-all duration-300 ${
            isNeon 
              ? 'border-cyan-500/10' 
              : 'border-neutral-900 hover:border-neutral-800 shadow-[0_4px_25px_rgba(6,182,212,0.02)]'
          }`}>
            <div className="absolute top-1/2 right-4 -translate-y-1/2 opacity-5 pointer-events-none">
              <CheckCircle className="w-24 h-24 text-cyan-400" />
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] text-neutral-500 font-mono tracking-wider uppercase">
                Recovered Debt Cleared
              </span>
              <span className="p-1 px-2 rounded bg-cyan-900/20 text-cyan-400 border border-cyan-500/10 text-[9px] font-mono">
                Frictionless Clearance
              </span>
            </div>
            <h2 className="text-3xl font-bold text-white tracking-tight flex items-baseline gap-1 font-mono">
              <span className="text-xl text-cyan-400 font-normal">₹</span>
              {totalRecovered.toLocaleString()}
            </h2>
            <div className="mt-3 text-[10px] text-neutral-400 font-mono flex items-center gap-1">
              <span>Total recovery: <span className="text-cyan-400 font-bold">{recoveryCount.length}</span> transactions updated.</span>
            </div>
          </div>

        </section>

        {/* Central Console Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left panel: Log Transaction Trigger Forms (Col 5) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Action Card: Digital Bill Invoicer compilation */}
            <div className={`p-6 rounded-2xl bg-black border ${
              isNeon ? 'border-emerald-500/20 shadow-md' : 'border-neutral-900 hover:border-neutral-800'
            }`}>
              <h2 className="text-base font-bold text-white mb-2 font-mono flex items-center gap-2">
                <FileSpreadsheet className={`w-4 h-4 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                Premium Smart Invoicing
              </h2>
              <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
                Compile dynamic line items, auto-calculate service taxation fees, and generate premium browser printable invoices instantly.
              </p>
              
              <button
                onClick={() => setShowInvoicer(true)}
                className={`w-full py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  isNeon 
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg font-mono' 
                    : 'bg-gradient-to-r from-fuchsia-500 to-cyan-500 hover:opacity-95 text-white shadow-lg'
                }`}
              >
                <Plus className="w-4 h-4" />
                Initialize Digital Invoice
              </button>
            </div>

            {/* Quick manual ledger transaction entry form */}
            <div 
              id="manual-ledger-form-card"
              className={`p-6 rounded-2xl bg-black border transition-all ${
                isNeon ? 'border-emerald-500/10' : 'border-neutral-900'
              }`}
            >
              <h2 className="text-base font-bold text-white mb-4 font-mono flex items-center justify-between gap-2">
                <span className="flex items-center gap-2">
                  <Settings className={`w-4 h-4 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                  Quick Ledger Logging
                </span>
                <div className="flex items-center gap-2">
                  {(manualName || manualPhone || manualAmt || manualDesc) && (
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm("Clear Quick Ledger draft fields?")) {
                          setManualName('');
                          setManualPhone('');
                          setManualAmt('');
                          setManualType('PAID');
                          setManualDesc('');
                          localStorage.removeItem('THEAI_HUB_QUICK_LEDGER_DRAFT');
                        }
                      }}
                      className="px-1.5 py-0.5 text-[8px] font-mono rounded bg-red-950/40 text-red-400 border border-red-500/20 hover:bg-red-900/20 cursor-pointer uppercase transition-all"
                      title="Clear draft values"
                    >
                      Clear
                    </button>
                  )}
                  <span className="text-[8px] text-neutral-500 font-mono tracking-wider uppercase animate-pulse">
                    Auto-saved
                  </span>
                </div>
              </h2>

              <form onSubmit={handleAddManualTransaction} className="space-y-3.5 text-xs font-mono">
                <div>
                  <label className="block text-neutral-400 mb-1">Customer Identifier</label>
                  <input
                    type="text"
                    required
                    value={manualName}
                    onChange={(e) => setManualName(e.target.value)}
                    placeholder="e.g. Aman Dixit"
                    className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg p-2.5 text-white outline-none focus:border-neutral-700"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-neutral-400 mb-1">Amount (INR)</label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={manualAmt}
                      onChange={(e) => setManualAmt(e.target.value)}
                      placeholder="₹ 5,000"
                      className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg p-2.5 text-white outline-none focus:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block text-neutral-400 mb-1">Classification Type</label>
                    <select
                      value={manualType}
                      onChange={(e) => setManualType(e.target.value as TransactionType)}
                      className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg p-2.5 text-white outline-none cursor-pointer focus:border-neutral-700"
                    >
                      <option value="PAID">PAID (Clear)</option>
                      <option value="DUE">DUE (Udhari)</option>
                      <option value="RECOVERY">RECOVERY (Debt)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-neutral-400 mb-1">Mobile Contact No.</label>
                  <input
                    type="text"
                    value={manualPhone}
                    onChange={(e) => setManualPhone(e.target.value)}
                    placeholder="e.g. +91 945281483"
                    className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg p-2.5 text-white outline-none focus:border-neutral-700"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 mb-1">Internal Description / Memo</label>
                  <input
                    type="text"
                    value={manualDesc}
                    onChange={(e) => setManualDesc(e.target.value)}
                    placeholder="Purchase of battery bank"
                    className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg p-2.5 text-white outline-none focus:border-neutral-700"
                  />
                </div>

                <button
                  type="submit"
                  className={`w-full py-2 px-4 rounded-xl font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                    isNeon 
                      ? 'bg-neutral-800 hover:bg-emerald-500/10 border border-emerald-500/20 hover:border-emerald-500 text-emerald-400' 
                      : 'bg-neutral-800 hover:bg-fuchsia-500/10 border border-fuchsia-500/20 hover:border-fuchsia-500 text-fuchsia-400'
                  }`}
                >
                  Log Ledger Block
                </button>
              </form>
            </div>

            {/* Action Card: Gmail Secure Integration Node */}
            <div className={`p-6 rounded-2xl bg-black border ${
              isNeon ? 'border-emerald-500/15' : 'border-neutral-900'
            }`}>
              <h2 className="text-sm font-bold text-white font-mono flex items-center justify-between mb-4 pb-2 border-b border-neutral-900">
                <span className="flex items-center gap-2">
                  <Mail className={`w-4 h-4 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                  Gmail Secure Node
                </span>
                {gmailConnected ? (
                  <span className="p-1 px-[6px] rounded bg-emerald-950/40 text-emerald-400 border border-emerald-500/20 text-[8px] uppercase font-mono animate-pulse">
                    SYS_ACTIVE
                  </span>
                ) : (
                  <span className="p-1 px-[6px] rounded bg-neutral-900 text-neutral-500 border border-neutral-800 text-[8px] uppercase font-mono">
                    OFFLINE
                  </span>
                )}
              </h2>

              {!gmailConnected ? (
                <div className="space-y-3 font-mono text-xs">
                  <p className="text-neutral-400 leading-relaxed text-[11px]">
                    Connect your authorized Google workspace to activate real-time digital billing and invoice delivery.
                  </p>
                  <button
                    onClick={handleConnectGmail}
                    disabled={gmailLoading}
                    className={`w-full py-2 px-4 rounded-xl font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2 ${
                      isNeon 
                        ? 'bg-neutral-800 hover:bg-emerald-500/10 border border-emerald-500/20 hover:border-emerald-500 text-emerald-400' 
                        : 'bg-neutral-800 hover:bg-fuchsia-500/10 border border-fuchsia-500/20 hover:border-fuchsia-500 text-fuchsia-400'
                    }`}
                  >
                    {gmailLoading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        Authorizing...
                      </>
                    ) : (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        Connect Google Gmail
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="space-y-4 font-mono text-xs">
                  <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800/80 flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <span className="text-[9px] text-neutral-500 block uppercase">Connected Session</span>
                      <span className="text-white font-medium text-[11px] block truncate" title={auth.currentUser?.email || 'Active Operator'}>
                        {auth.currentUser?.email || 'Active Operator'}
                      </span>
                    </div>
                    <button
                      onClick={handleDisconnectGmail}
                      className="text-[9px] shrink-0 text-red-400 hover:text-red-300 transition-colors uppercase border border-red-500/20 rounded px-1.5 py-0.5 cursor-pointer hover:bg-red-950/25"
                    >
                      Disconnect
                    </button>
                  </div>

                  {/* Sent list logs */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-neutral-500 uppercase tracking-widest">Sent Ledger Records</span>
                      <button
                        onClick={loadGmailLogs}
                        disabled={logsLoading}
                        className="text-neutral-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <RefreshCw className={`w-2.5 h-2.5 ${logsLoading ? 'animate-spin' : ''}`} />
                        Sync
                      </button>
                    </div>

                    <div className="max-h-[160px] overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                      {logsLoading ? (
                        <div className="text-center py-6 text-neutral-600 text-[10px] animate-pulse">
                          Querying Gmail sent registries...
                        </div>
                      ) : sentLogs.length > 0 ? (
                        sentLogs.map((log) => (
                          <div 
                            key={log.id} 
                            className="p-2 rounded bg-neutral-950 border border-neutral-900/50 flex flex-col gap-0.5 text-[10px]"
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-white font-bold truncate max-w-[130px]">{log.to}</span>
                              <span className="text-[8px] text-neutral-600 shrink-0">{new Date(log.date).toLocaleDateString()}</span>
                            </div>
                            <span className="text-neutral-400 truncate">{log.subject}</span>
                            <span className="text-[9px] text-neutral-500 truncate">{log.snippet}</span>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-6 text-neutral-600 text-[10px] border border-dashed border-neutral-900 rounded-lg">
                          No recent bills dispatched via Gmail
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Action Card: UPI Secure Gateway Unlock Terminal */}
            <div className={`p-6 rounded-2xl bg-black border ${
              isPremiumUnlocked
                ? 'border-amber-500/30 bg-amber-950/5 shadow-[0_4px_30px_rgba(245,158,11,0.02)]'
                : isNeon 
                  ? 'border-emerald-500/15' 
                  : 'border-neutral-900'
            }`}>
              <h2 className="text-sm font-bold text-white font-mono flex items-center justify-between mb-4 pb-2 border-b border-neutral-900">
                <span className="flex items-center gap-2">
                  <Flame className={`w-4 h-4 ${isPremiumUnlocked ? 'text-amber-400 font-bold' : isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                  UPI Verify Gate
                </span>
                {isPremiumUnlocked ? (
                  <span className="p-1 px-[6px] rounded bg-amber-950/40 text-amber-400 border border-amber-500/20 text-[8px] uppercase font-mono animate-pulse">
                    VIP_ACTIVE
                  </span>
                ) : (
                  <span className="p-1 px-[6px] rounded bg-neutral-900 text-neutral-500 border border-neutral-800 text-[8px] uppercase font-mono">
                    ₹1 TO UNLOCK
                  </span>
                )}
              </h2>

              {!isPremiumUnlocked ? (
                <div className="space-y-4 font-mono text-xs">
                  <p className="text-neutral-400 leading-relaxed text-[11px]">
                    Transmit <span className="text-white font-bold">₹1</span> to the verified gateway to unlock real-time predictive ML diagnostics and reports.
                  </p>

                  <div className="flex flex-col sm:flex-row items-center gap-4 bg-neutral-950/80 p-3.5 rounded-xl border border-neutral-900">
                    {/* Generates standard black UPI flow code */}
                    <div className="shrink-0 p-1.5 bg-white rounded-lg flex items-center justify-center shadow-lg border border-neutral-800">
                      <img 
                        src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&margin=4&color=0-0-0&data=upi%3A%2F%2Fpay%3Fpa%3D95222209478%40pytes%26pn%3DTHEAI%2520Hub%252520Premium%26am%3D1%26cu%3DINR%26tn%3DUnlock%252520Premium"
                        alt="95222209478@pytes 1 RS"
                        className="w-24 h-24 pointer-events-none"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="space-y-2 flex-1 text-center sm:text-left">
                      <span className="text-[9px] text-neutral-500 block uppercase tracking-wider">Gateway Address</span>
                      <span className="text-white font-bold font-mono text-xs break-all bg-neutral-900 p-1.5 rounded select-all border border-neutral-800 text-center sm:text-left block">
                        95222209478@pytes
                      </span>
                      <a 
                        href="upi://pay?pa=95222209478@pytes&pn=THEAI%20Hub%20Premium&am=1&cu=INR&tn=Unlock%20Premium%2520Ledger"
                        className={`inline-flex items-center gap-1.5 py-1 px-3 rounded-lg text-[9px] uppercase font-bold text-center border transition-all ${
                          isNeon 
                            ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/10' 
                            : 'bg-fuchsia-500/5 border-fuchsia-500/20 text-fuchsia-400 hover:bg-fuchsia-500/10'
                        }`}
                      >
                        <ArrowUpRight className="w-3 h-3" />
                        Pay on Mobile (Deep Link)
                      </a>
                    </div>
                  </div>

                  <div className="space-y-2 pt-1">
                    <label className="block text-neutral-500 text-[10px] uppercase">Transaction Ref / UTR ID</label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        value={premiumRefCode}
                        onChange={(e) => setPremiumRefCode(e.target.value)}
                        placeholder="UTR Code or type any text"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 text-white text-xs outline-none focus:border-neutral-700"
                      />
                      <button
                        onClick={() => handleUnlockPremium(premiumRefCode)}
                        disabled={unlockingPremium}
                        className={`absolute right-1.5 top-1.5 py-1.5 px-3 rounded-lg font-bold uppercase tracking-wider text-[10px] transition-all cursor-pointer flex items-center justify-center gap-1 ${
                          isNeon 
                            ? 'bg-emerald-500 text-black hover:bg-emerald-400' 
                            : 'bg-fuchsia-500 text-white hover:bg-fuchsia-400'
                        }`}
                      >
                        {unlockingPremium ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Check className="w-3 h-3" />
                        )}
                        Verify Keys
                      </button>
                    </div>

                    {unlockStatus && (
                      <div className={`p-2.5 rounded font-mono text-[10px] text-center border ${
                        unlockStatus.includes('UNLOCKED') 
                          ? 'bg-emerald-950/20 border-emerald-500/20 text-emerald-400' 
                          : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                      }`}>
                        {unlockStatus}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-3 font-mono text-xs text-neutral-400">
                  <div className="p-3 bg-neutral-900/60 border border-amber-500/10 rounded-xl flex items-center gap-2.5">
                    <CheckCircle className="w-5 h-5 text-amber-400 shrink-0" />
                    <div>
                      <span className="text-[9px] uppercase text-amber-500 block font-bold font-mono">VIP System Loaded</span>
                      <p className="text-[11px] text-white">Full diagnostics unlocked and active.</p>
                    </div>
                  </div>

                  <p className="text-[10px] text-neutral-500 leading-relaxed uppercase tracking-wider font-mono">
                    System synchronizes client payment records dynamically. Diagnostics are fully active.
                  </p>

                  <button
                    onClick={handleLockPremium}
                    className="w-full py-1.5 px-3 rounded-lg border border-neutral-850 text-[10px] uppercase font-bold text-neutral-500 hover:text-red-400 hover:border-red-500/20 transition-all cursor-pointer hover:bg-red-950/10"
                  >
                    Lock System (Deactivate VIP Mode)
                  </button>
                </div>
              )}
            </div>

          </div>

          {/* Right panel: Live Ledger Tables & Records Search Matrix (Col 7) */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className={`p-6 rounded-2xl bg-black border overflow-hidden ${
              isNeon ? 'border-emerald-500/10' : 'border-neutral-900'
            }`}>
              {/* Tab Selector & Reset Caches Action Block */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-900 pb-4 mb-4">
                <div>
                  <h2 className="text-base font-bold text-white font-mono flex items-center gap-2">
                    <Activity className={`w-4 h-4 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                    Secure Ledger Registry
                  </h2>
                  <p className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider mt-0.5 animate-pulse">
                    INTEGRATED WITH THEAI HUB CORE STACK &bull; HARSHVARDHAN SIGNATURE
                  </p>
                </div>

                <div className="flex items-center gap-2 font-mono">
                  <button
                    onClick={handleResetLedger}
                    title="Wipe local storage cache"
                    className="p-1.5 px-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-500 hover:text-red-400 text-[9px] hover:border-red-500/20 transition-all cursor-pointer flex items-center gap-1 self-start"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset Cache
                  </button>
                </div>
              </div>

              {/* High-Contrast Interactive Registry Tabs */}
              <div className="flex space-x-2 border-b border-neutral-900 pb-3 mb-4">
                <button
                  onClick={() => setActiveRegistryTab('TRANSACTIONS')}
                  className={`flex-1 py-2 px-3 rounded-lg font-mono text-xs font-bold uppercase transition-all tracking-wider cursor-pointer flex items-center justify-center gap-2 ${
                    activeRegistryTab === 'TRANSACTIONS'
                      ? isNeon
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]'
                        : 'bg-fuchsia-500/10 text-fuchsia-400 border border-fuchsia-500/30'
                      : 'text-neutral-500 hover:text-neutral-300 border border-transparent'
                  }`}
                >
                  📋 All General Bills Log
                </button>
                <button
                  onClick={() => setActiveRegistryTab('CUSTOMER_ACCOUNTS')}
                  className={`flex-1 py-2 px-3 rounded-lg font-mono text-xs font-bold uppercase transition-all tracking-wider cursor-pointer flex items-center justify-center gap-2 ${
                    activeRegistryTab === 'CUSTOMER_ACCOUNTS'
                      ? isNeon
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]'
                        : 'bg-fuchsia-500/10 text-fuchsia-400 border border-fuchsia-500/30'
                      : 'text-neutral-500 hover:text-neutral-300 border border-transparent'
                  }`}
                >
                  👥 Customer Credit Directory
                </button>
              </div>

              {/* Filtering Search Bar */}
              <div className="flex flex-col sm:flex-row gap-3 text-xs mb-4">
                {/* Search query input */}
                <div className="flex-1 relative font-mono">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={
                      activeRegistryTab === 'TRANSACTIONS' 
                        ? "Search client, specifications, bill ID..." 
                        : "Search client name or mobile contact..."
                    }
                    className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg pl-9 pr-4 py-2 text-white placeholder-neutral-600 outline-none text-xs focus:border-neutral-700"
                  />
                </div>

                {/* Status classifier selector pills - available only under TRANSACTION log Tab */}
                {activeRegistryTab === 'TRANSACTIONS' && (
                  <div className="flex rounded-lg bg-neutral-900 p-1 border border-neutral-800 text-[10px] font-mono font-bold tracking-wider">
                    {(['ALL', 'PAID', 'DUE', 'RECOVERY'] as const).map((filterOpt) => (
                      <button
                        key={filterOpt}
                        onClick={() => setTypeFilter(filterOpt)}
                        className={`px-3 py-1 rounded transition-colors uppercase cursor-pointer ${
                          typeFilter === filterOpt
                            ? isNeon 
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                              : 'bg-fuchsia-500/10 text-fuchsia-400 border border-fuchsia-500/20'
                            : 'text-neutral-500 hover:text-neutral-300'
                        }`}
                      >
                        {filterOpt}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* TAB 1 CONTENT: TRANSACTION RECORDS */}
              {activeRegistryTab === 'TRANSACTIONS' && (
                <div className="overflow-x-auto min-h-[300px]">
                  <table className="w-full text-left border-collapse font-mono text-xs text-neutral-400">
                    <thead>
                      <tr className="border-b border-neutral-900 text-[10px] text-neutral-500">
                        <th className="py-2 px-3 font-bold">BLOCK META</th>
                        <th className="py-2 px-3 font-bold">CLIENT NAME</th>
                        <th className="py-2 px-3 font-bold text-center">CLASSIFIED</th>
                        <th className="py-2 px-3 font-bold text-right">AMOUNT (INR)</th>
                        <th className="py-2 px-3 text-center print:hidden">ACTIONS</th>
                      </tr>
                    </thead>
                    <tbody>
                      <AnimatePresence initial={false}>
                        {filteredTxns.map((t) => (
                          <motion.tr
                            key={t.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, x: -15 }}
                            className="border-b border-neutral-900/50 hover:bg-neutral-900/20 transition-colors"
                          >
                            {/* Transaction ID & Time details */}
                            <td className="py-3 px-3">
                              <span className="text-[10px] font-bold text-white block">
                                {t.billId}
                              </span>
                              <span className="text-[9px] text-neutral-600 uppercase block mt-0.5">
                                {new Date(t.date).toLocaleDateString()} &bull; {new Date(t.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </td>

                            {/* Customer Identification */}
                            <td className="py-3 px-3 font-sans">
                              <span className="text-white font-semibold block">{t.customerName}</span>
                              {t.customerPhone && (
                                <span className="text-[10px] text-neutral-500 block font-mono mt-0.5">{t.customerPhone}</span>
                              )}
                            </td>

                            {/* Classification classification indicator */}
                            <td className="py-3 px-3 text-center">
                              <span className={`inline-block py-0.5 px-2 rounded-md text-[9px] uppercase font-bold border ${
                                t.type === 'PAID' 
                                  ? 'bg-emerald-950/30 text-emerald-400 border-emerald-500/20' 
                                  : t.type === 'DUE' 
                                    ? 'bg-red-950/30 text-red-400 border-red-500/20' 
                                    : 'bg-cyan-950/30 text-cyan-400 border-cyan-500/20'
                              }`}>
                                {t.type}
                              </span>
                            </td>

                            {/* Ledger Amount column */}
                            <td className="py-3 px-3 text-right">
                              <span className="text-white font-semibold text-xs font-mono">
                                ₹{t.amount.toLocaleString()}
                              </span>
                              <span className="text-[9px] text-neutral-500 block truncate max-w-[120px] ml-auto mt-0.5 font-sans italic" title={t.description}>
                                {t.description || 'No notes added'}
                              </span>
                            </td>

                            {/* Quick Action Buttons (One-Click PDF/HTML Download + Wipe) */}
                            <td className="py-3 px-3 print:hidden">
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => setSelectedPreviewTxn(t)}
                                  className={`p-1 rounded cursor-pointer transition-colors ${
                                    isNeon 
                                      ? 'text-emerald-400 hover:bg-emerald-500/10 hover:text-emerald-300' 
                                      : 'text-fuchsia-400 hover:bg-fuchsia-500/10 hover:text-fuchsia-300'
                                  }`}
                                  title="View & Download Bill Photo/PDF"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteTransaction(t.id)}
                                  className="text-neutral-500 hover:text-red-400 transition-colors p-1 rounded hover:bg-neutral-900 cursor-pointer"
                                  title="Delete entry block"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </motion.tr>
                        ))}
                      </AnimatePresence>

                      {filteredTxns.length === 0 && (
                        <tr>
                          <td colSpan={5} className="text-center py-12 text-neutral-600 text-xs">
                            [ Authorized ledger records map is currently empty. Query criteria mismatch or zero logs logged ]
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {/* TAB 2 CONTENT: LIVE CUSTOMER UDHARI LEDGER DIRECTORY */}
              {activeRegistryTab === 'CUSTOMER_ACCOUNTS' && (
                <div className="overflow-x-auto min-h-[300px]">
                  <table className="w-full text-left border-collapse font-sans text-xs text-neutral-400">
                    <thead>
                      <tr className="border-b border-neutral-900 text-[10px] text-neutral-500 font-mono text-left">
                        <th className="py-2.5 px-3 font-bold uppercase">Customer Identity</th>
                        <th className="py-2.5 px-3 font-bold uppercase text-right">Total Bills</th>
                        <th className="py-2.5 px-3 font-bold uppercase text-right">Cleared Cash</th>
                        <th className="py-2.5 px-3 font-bold uppercase text-right text-red-400">Pending Dues</th>
                        <th className="py-2.5 px-3 font-bold uppercase text-center print:hidden">Ledger Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <AnimatePresence initial={false}>
                        {customerLedgers
                          .filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()) || (c.phone && c.phone.includes(searchQuery)))
                          .map((client) => (
                            <motion.tr
                              key={client.name}
                              initial={{ opacity: 0, scale: 0.98 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0 }}
                              className="border-b border-neutral-900/40 hover:bg-neutral-900/10 transition-colors"
                            >
                              {/* Customer Identity Card */}
                              <td className="py-3.5 px-3">
                                <span className="text-white font-bold block text-sm">{client.name}</span>
                                <div className="flex items-center gap-2 mt-1 text-[10px] text-neutral-500 font-mono">
                                  <span>{client.phone || 'NO PHONE ATTACHED'}</span>
                                  <span>&bull;</span>
                                  <span>{client.transactions.length} txns</span>
                                </div>
                              </td>

                              {/* Total Dues/Billed */}
                              <td className="py-3.5 px-3 text-right font-mono text-neutral-300">
                                ₹{client.totalBilled.toLocaleString()}
                              </td>

                              {/* Total Paid/Recovered */}
                              <td className="py-3.5 px-3 text-right font-mono text-emerald-400">
                                ₹{client.totalPaid.toLocaleString()}
                              </td>

                              {/* Net Remaining Balance */}
                              <td className="py-3.5 px-3 text-right">
                                <span className={`inline-block font-mono text-xs font-bold py-0.5 px-2 rounded-md ${
                                  client.balance > 0 
                                    ? 'bg-red-950/40 text-red-400 border border-red-500/20' 
                                    : 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20'
                                }`}>
                                  ₹{client.balance.toLocaleString()}
                                </span>
                              </td>

                              {/* Action Items: (1-Click Statement Download + Pre-fill Payments Form) */}
                              <td className="py-3.5 px-3 text-center print:hidden font-mono">
                                <div className="flex items-center justify-center gap-2">
                                  {/* Receive Payment / Log Recovery Button */}
                                  {client.balance > 0 ? (
                                    <button
                                      type="button"
                                      onClick={() => handleSelectCustomerForRecovery(client.name, client.phone)}
                                      className="py-1 px-2.5 rounded-lg text-[10px] font-bold bg-neutral-900 border border-neutral-800 text-cyan-400 hover:text-cyan-300 hover:border-cyan-500/30 transition-all cursor-pointer flex items-center gap-1"
                                      title="Click to quickly pre-fill standard cashier payment recovery entry form"
                                    >
                                      ₹ Pay
                                    </button>
                                  ) : (
                                    <span className="text-[9px] text-neutral-600 uppercase border border-neutral-900 py-1 px-2 rounded-lg bg-neutral-950">
                                      Cleared
                                    </span>
                                  )}

                                  {/* Preview Client Credit Statement */}
                                  <button
                                    type="button"
                                    onClick={() => setSelectedPreviewStatement({ name: client.name, data: client })}
                                    className={`py-1 px-2 rounded-lg text-[10px] font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                                      isNeon
                                        ? 'bg-neutral-900 border-neutral-800 text-emerald-400 hover:border-emerald-500/30 hover:bg-emerald-500/5'
                                        : 'bg-neutral-900 border-neutral-800 text-fuchsia-400 hover:border-fuchsia-500/30 hover:bg-fuchsia-500/5'
                                    }`}
                                    title="View & Download Credit Statement Photo/PDF"
                                  >
                                    <Eye className="w-3 h-3" />
                                    Statement
                                  </button>
                                </div>
                              </td>
                            </motion.tr>
                          ))
                        }
                      </AnimatePresence>

                      {customerLedgers.length === 0 && (
                        <tr>
                          <td colSpan={5} className="text-center py-12 text-neutral-600 text-xs font-mono">
                            [ Outstanding credit balance directory is empty. Log a dynamic DUE or PAID entry block to sync client database records ]
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>

        </div>

        {/* AI-Ready Smart Assist Diagnostic block */}
        <div className="mt-4 relative overflow-hidden rounded-2xl">
          <AISmartAssistant 
            transactions={transactions} 
            session={session} 
            theme={theme} 
          />

          {!isPremiumUnlocked && (
            <div className="absolute inset-0 bg-black/75 backdrop-blur-md flex flex-col items-center justify-center text-center p-6 border border-neutral-900 rounded-2xl z-20">
              <div className="absolute top-3 right-4 text-[8px] tracking-widest font-mono text-amber-500 uppercase flex items-center gap-1.5 bg-black/60 p-1 px-2 rounded-full border border-neutral-800">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping"></span>
                Secure Gate Protected
              </div>

              <div className={`p-4 rounded-full bg-neutral-950/95 mb-4 border border-dashed flex items-center justify-center ${
                isNeon ? 'border-amber-500/30 text-amber-400' : 'border-neutral-850 text-amber-400'
              }`}>
                <Lock className="w-7 h-7 text-amber-400" />
              </div>

              <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider mb-2">
                Predictive AI Assistant Protected
              </h3>
              <p className="text-xs text-neutral-450 max-w-md mx-auto mb-5 leading-relaxed font-sans text-neutral-400">
                Dynamic cache aggregation, outstanding client predictions, and automated ledger diagnostics are locked behind secure node encryption. Verify ₹1 payment to unlock.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-3 font-mono">
                {/* Instant Test Drive Unlock button */}
                <button
                  type="button"
                  onClick={() => handleUnlockPremium('MOCK_TEST_UTR_CODE')}
                  className={`py-2 px-5 rounded-xl font-bold uppercase tracking-wider text-[11px] transition-all cursor-pointer shadow-lg flex items-center gap-1.5 ${
                    isNeon 
                      ? 'bg-amber-500 text-black hover:bg-amber-400' 
                      : 'bg-gradient-to-r from-amber-500 to-yellow-600 text-white hover:opacity-95'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Auto-Unlock AI Instantly
                </button>
                <span className="text-neutral-600 text-[10px]">OR</span>
                <a
                  href="#manual-ledger-form-card"
                  onClick={(e) => {
                    e.preventDefault();
                    const el = document.getElementById('manual-ledger-form-card');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="py-2 px-4 rounded-xl font-bold uppercase tracking-wider text-[10.5px] border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700 transition-all cursor-pointer"
                >
                  Scan QR Terminal
                </a>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Slideout Full Digital Billing Document compiler overlay */}
      <AnimatePresence>
        {showInvoicer && (
          <BillingInvoice
            session={session}
            theme={theme}
            onSaveInvoice={handleSaveInvoiceFromModal}
            onClose={() => setShowInvoicer(false)}
          />
        )}
      </AnimatePresence>

      {/* Visual Bill Preview & Export Modal Dialog */}
      <AnimatePresence>
        {selectedPreviewTxn && (
          <div className="fixed inset-0 z-[100] overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`w-full max-w-lg rounded-2xl bg-neutral-950 border overflow-hidden p-6 ${
                isNeon ? 'border-emerald-500/40' : 'border-fuchsia-100/10'
              }`}
            >
              {/* Header actions */}
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-neutral-900 font-mono text-xs">
                <span className="text-neutral-400 font-bold uppercase tracking-widest flex items-center gap-1.5">
                  <Sparkles className={`w-4 h-4 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                  Bill Document Preview
                </span>
                <button
                  onClick={() => setSelectedPreviewTxn(null)}
                  className="px-2.5 py-1 text-neutral-500 hover:text-white rounded-md bg-neutral-900 border border-neutral-800 transition-colors cursor-pointer"
                >
                  Close [Esc]
                </button>
              </div>

              {/* The element to be screenshotted by html2canvas */}
              <div 
                id="preview-bill-render-capture" 
                className="p-6 rounded-xl bg-black border border-neutral-900 font-mono text-xs text-neutral-300 relative select-none"
              >
                {/* Branding */}
                <div className="text-center mb-5 pb-4 border-b border-neutral-900 border-dashed">
                  <span className="text-xs font-extrabold uppercase tracking-widest text-white">
                    {session.shopName}
                  </span>
                  <p className="text-[9px] text-neutral-500 mt-0.5 uppercase">
                    Operator Signature: {session.username}
                  </p>
                  <p className="text-[8px] text-neutral-600 mt-1 uppercase">
                    The AI Hub Hub-Ledger Audit Token
                  </p>
                </div>

                {/* Metadata */}
                <div className="grid grid-cols-2 gap-2 text-[10px] mb-4 pb-4 border-b border-neutral-900 border-dashed">
                  <div>
                    <span className="text-neutral-500">BILL ID:</span>{' '}
                    <span className="text-white font-bold">{selectedPreviewTxn.billId}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-neutral-500">DATE:</span>{' '}
                    <span className="text-white">{new Date(selectedPreviewTxn.date).toLocaleDateString()}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500">CLIENT:</span>{' '}
                    <span className="text-white font-semibold uppercase">
                      {selectedPreviewTxn.customerName}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-neutral-500">CLASSIFIED:</span>{' '}
                    <span className={`font-semibold px-1 rounded text-[9px] ${
                      selectedPreviewTxn.type === 'PAID' ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20' :
                      selectedPreviewTxn.type === 'DUE' ? 'bg-red-950/40 text-red-400 border border-red-500/20' :
                      'bg-cyan-950/40 text-cyan-400 border border-cyan-500/20'
                    }`}>
                      {selectedPreviewTxn.type}
                    </span>
                  </div>
                </div>

                {/* Specifications table */}
                <div className="space-y-1.5 mb-5 min-h-[60px] text-[10px]">
                  <div className="grid grid-cols-12 text-neutral-500 border-b border-neutral-900 pb-1 font-bold">
                    <span className="col-span-6 text-left">SPECIFICATION</span>
                    <span className="col-span-2 text-center">QTY</span>
                    <span className="col-span-4 text-right">TOTAL</span>
                  </div>

                  {selectedPreviewTxn.items && selectedPreviewTxn.items.length > 0 ? (
                    selectedPreviewTxn.items.map((item, idx) => (
                      <div key={idx} className="grid grid-cols-12 text-neutral-300 py-0.5 border-b border-neutral-900/40">
                        <span className="col-span-6 truncate">{item.name}</span>
                        <span className="col-span-2 text-center">{item.quantity}</span>
                        <span className="col-span-4 text-right text-white font-semibold">
                          ₹{(item.quantity * item.price).toLocaleString()}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="grid grid-cols-12 text-neutral-300 py-0.5 border-b border-neutral-900/40">
                      <span className="col-span-8 truncate italic text-neutral-500">
                        {selectedPreviewTxn.description || 'Ledger transaction log'}
                      </span>
                      <span className="col-span-4 text-right text-white font-semibold">
                        ₹{selectedPreviewTxn.amount.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>

                {/* Calculations stack */}
                <div className="space-y-1 pt-3 border-t border-neutral-900 border-dashed text-[10px]">
                  {selectedPreviewTxn.items && selectedPreviewTxn.items.length > 0 && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Subtotal Compilations:</span>
                        <span className="text-neutral-300">
                          ₹{selectedPreviewTxn.items.reduce((acc, current) => acc + (current.price * current.quantity), 0).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Convenience handling tax (5%):</span>
                        <span className="text-neutral-300">
                          ₹{Math.round(selectedPreviewTxn.items.reduce((acc, current) => acc + (current.price * current.quantity), 0) * 0.05).toLocaleString()}
                        </span>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between text-xs border-t border-neutral-900 pt-2 font-bold text-white">
                    <span>Grand Total Liability:</span>
                    <span className={isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}>
                      ₹{selectedPreviewTxn.amount.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Secure footer */}
                <div className="mt-6 pt-3 border-t border-neutral-900 border-dotted text-center text-[7.5px] text-neutral-500 uppercase leading-relaxed">
                  Autogenerated Token: {selectedPreviewTxn.id.toUpperCase()}<br />
                  Secured locally under THEAi Hub Cryptography suite
                </div>
              </div>

              {/* Modal Download Actions bar */}
              <div className="mt-4 flex flex-col gap-2 font-mono text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      const input = document.getElementById('preview-bill-render-capture');
                      if (!input) return;
                      html2canvas(input, {
                        backgroundColor: '#030303',
                        scale: 2,
                        useCORS: true,
                        logging: false
                      }).then((canvas) => {
                        const imgData = canvas.toDataURL('image/png');
                        const link = document.createElement('a');
                        link.href = imgData;
                        link.download = `THEAI_Bill_Photo_${selectedPreviewTxn.billId}_${selectedPreviewTxn.customerName.replace(/\s+/g, '_')}.png`;
                        link.click();
                      }).catch((err) => {
                        console.error('Canvas error: ', err);
                        alert('Error compiling photo image files.');
                      });
                    }}
                    className={`p-2 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer border ${
                      isNeon
                        ? 'border-emerald-500/20 bg-neutral-900 text-emerald-400 hover:bg-emerald-500/10'
                        : 'border-fuchsia-500/20 bg-neutral-900 text-fuchsia-400 hover:bg-fuchsia-500/10'
                    }`}
                  >
                    <Image className="w-3.5 h-3.5" />
                    Download Photo
                  </button>

                  <button
                    onClick={() => {
                      const style = document.createElement('style');
                      style.innerHTML = `
                        @media print {
                          body * { display: none !important; }
                          #preview-bill-render-capture, #preview-bill-render-capture * { display: block !important; }
                          #preview-bill-render-capture { position: absolute !important; left: 0 !important; top: 0 !important; width: 100% !important; background: #fff !important; color: #000 !important; border: none !important; }
                          #preview-bill-render-capture span, #preview-bill-render-capture p { color: #000 !important; }
                        }
                      `;
                      document.head.appendChild(style);
                      window.print();
                      document.head.removeChild(style);
                    }}
                    className={`p-2 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer border ${
                      isNeon
                        ? 'border-emerald-500/20 bg-neutral-900 text-emerald-400 hover:bg-emerald-500/10'
                        : 'border-fuchsia-500/20 bg-neutral-900 text-fuchsia-400 hover:bg-fuchsia-500/10'
                    }`}
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Print / PDF
                  </button>
                </div>

                <button
                  onClick={() => downloadSingleBill(selectedPreviewTxn)}
                  className="w-full p-2 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer bg-neutral-900 hover:bg-neutral-850 text-white border border-neutral-800"
                >
                  <Download className="w-3.5 h-3.5" />
                  Get Offline HTML Bill Document
                </button>

                {/* Gmail secure sending portal integration */}
                <div className="mt-2 pt-3 border-t border-neutral-900/50 space-y-2">
                  <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold flex items-center gap-1.5 font-mono">
                    <Mail className={`w-3.5 h-3.5 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                    Gmail Billing Dispatch
                  </span>
                  
                  {gmailConnected ? (
                    <div className="space-y-2">
                      <div className="relative">
                        <input
                          type="email"
                          required
                          value={recipientEmail}
                          onChange={(e) => setRecipientEmail(e.target.value)}
                          placeholder="recipient@domain.com"
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 pl-3 pr-24 text-white text-xs outline-none focus:border-neutral-750 font-mono"
                        />
                        <button
                          onClick={() => handleSendTxnEmail(selectedPreviewTxn, recipientEmail)}
                          disabled={emailSending}
                          className={`absolute right-1.5 top-1.5 py-1 px-3 rounded-lg font-bold uppercase tracking-wider text-[10px] transition-colors cursor-pointer flex items-center gap-1 ${
                            isNeon 
                              ? 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20' 
                              : 'bg-fuchsia-500/10 hover:bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/20'
                          }`}
                        >
                          {emailSending ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Send className="w-3 h-3" />
                          )}
                          Send
                        </button>
                      </div>
                      
                      {emailStatus && (
                        <div className={`p-2 rounded font-mono text-[10px] text-center border ${
                          emailStatus.startsWith('DISPATCHED') 
                            ? 'bg-emerald-950/20 border-emerald-500/20 text-emerald-400' 
                            : emailStatus.startsWith('REJECTED')
                              ? 'bg-red-950/20 border-red-500/20 text-red-100'
                              : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                        }`}>
                          {emailStatus}
                        </div>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={handleConnectGmail}
                      disabled={gmailLoading}
                      className="w-full p-2.5 rounded-xl font-bold font-mono tracking-wider text-[10px] uppercase transition-all border border-dashed border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-white bg-neutral-950 hover:bg-neutral-900 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      {gmailLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Lock className="w-3.5 h-3.5" />
                      )}
                      Link Gmail to Dispatch Electronic Bill
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Visual Client Statement preview modal dialog */}
      <AnimatePresence>
        {selectedPreviewStatement && (
          <div className="fixed inset-0 z-[100] overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`w-full max-w-2xl rounded-2xl bg-neutral-950 border overflow-hidden p-6 ${
                isNeon ? 'border-emerald-500/40' : 'border-fuchsia-100/10'
              }`}
            >
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-neutral-900 font-mono text-xs">
                <span className="text-neutral-400 font-bold uppercase tracking-widest flex items-center gap-1.5">
                  <Sparkles className={`w-4 h-4 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                  Credit Statement Ledger
                </span>
                <button
                  onClick={() => setSelectedPreviewStatement(null)}
                  className="px-2.5 py-1 text-neutral-500 hover:text-white rounded-md bg-neutral-900 border border-neutral-800 transition-colors cursor-pointer"
                >
                  Close [Esc]
                </button>
              </div>

              {/* Element to render and snapshot */}
              <div 
                id="preview-statement-render-capture" 
                className="p-6 rounded-xl bg-black border border-neutral-900 font-mono text-xs text-neutral-300 relative select-none"
              >
                {/* Header branding */}
                <div className="text-center mb-5 pb-4 border-b border-neutral-900 border-dashed">
                  <span className="text-sm font-extrabold uppercase tracking-widest text-white">
                    {session.shopName}
                  </span>
                  <p className="text-[9px] text-neutral-500 mt-0.5 uppercase tracking-wider">
                    Audited Customer Credit Statement Ledger
                  </p>
                  <p className="text-[8px] text-neutral-600 mt-1 uppercase">
                    Operator: {session.username} &bull; Generated: {new Date().toLocaleDateString()}
                  </p>
                </div>

                {/* Account card info */}
                <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80 mb-5 flex flex-col md:flex-row md:justify-between md:items-center gap-4 text-xs">
                  <div>
                    <span className="text-[9px] text-neutral-500 uppercase block">Customer Account Name</span>
                    <span className="text-white font-extrabold text-sm uppercase">{selectedPreviewStatement.name}</span>
                    <span className="text-[9px] text-neutral-500 block mt-1">Contact Phone: {selectedPreviewStatement.data.phone || 'N/A'}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-neutral-500 uppercase block">Account Health Status</span>
                    <span className={`inline-block font-sans font-bold text-[10px] px-2 py-0.5 mt-0.5 rounded ${
                      selectedPreviewStatement.data.balance > 0 
                        ? 'bg-red-950/40 text-red-400 border border-red-500/20' 
                        : 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {selectedPreviewStatement.data.balance > 0 ? 'DUES PENDING' : 'CLEAR HEALTHY'}
                    </span>
                  </div>
                </div>

                {/* Statement numbers summary */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  <div className="p-3 rounded-lg bg-neutral-900/40 border border-neutral-900 text-center">
                    <span className="text-[8px] text-neutral-500 uppercase block">Total Purchases</span>
                    <span className="text-white font-bold text-xs mt-1 block">₹{selectedPreviewStatement.data.totalBilled.toLocaleString()}</span>
                  </div>
                  <div className="p-3 rounded-lg bg-neutral-900/40 border border-neutral-900 text-center">
                    <span className="text-[8px] text-neutral-500 uppercase block">Paid Cleared</span>
                    <span className="text-emerald-400 font-bold text-xs mt-1 block">₹{selectedPreviewStatement.data.totalPaid.toLocaleString()}</span>
                  </div>
                  <div className={`p-3 rounded-lg text-center border ${
                    selectedPreviewStatement.data.balance > 0 ? 'bg-red-950/20 border-red-900/30 text-red-400' : 'bg-emerald-950/20 border-emerald-900/30 text-emerald-400'
                  }`}>
                    <span className="text-[8px] uppercase block">Outstanding Balance</span>
                    <span className="font-extrabold text-xs mt-1 block">₹{selectedPreviewStatement.data.balance.toLocaleString()}</span>
                  </div>
                </div>

                {/* Chronology rows list */}
                <div className="text-[10px] mb-4">
                  <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest mb-2">Itemized Ledger timeline</p>
                  <table className="w-full text-left font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-neutral-900 text-neutral-500 text-[8px] uppercase">
                        <th className="pb-1 text-left">Date</th>
                        <th className="pb-1 text-left">Bill Ref</th>
                        <th className="pb-1 text-center">Type</th>
                        <th className="pb-1 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedPreviewStatement.data.transactions.map((t: Transaction, idx: number) => (
                        <tr key={idx} className="border-b border-neutral-900/50 py-1 text-neutral-300">
                          <td className="py-1.5">{new Date(t.date).toLocaleDateString()}</td>
                          <td className="py-1.5 text-white font-semibold">{t.billId}</td>
                          <td className="py-1.5 text-center">
                            <span className={`px-1 text-[8px] rounded font-bold uppercase ${
                              t.type==='DUE' ? 'text-red-400' : t.type==='RECOVERY' ? 'text-cyan-400' : 'text-emerald-400'
                            }`}>
                              {t.type}
                            </span>
                          </td>
                          <td className="py-1.5 text-right font-bold text-white">₹{t.amount.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Secure stamp footer */}
                <div className="mt-6 pt-3 border-t border-neutral-900 border-dotted text-center text-[7px] text-neutral-500 uppercase leading-relaxed font-mono">
                  THEAI HUB LEDGER SYSTEM AUDIT STAMP &bull; PERSISTENT BLOCKCHAIN VALIDATED DATA SYNC MAP
                </div>
              </div>

              {/* Action buttons footer */}
              <div className="mt-4 flex flex-col gap-2 font-mono text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      const input = document.getElementById('preview-statement-render-capture');
                      if (!input) return;
                      html2canvas(input, {
                        backgroundColor: '#030303',
                        scale: 2,
                        useCORS: true,
                        logging: false
                      }).then((canvas) => {
                        const imgData = canvas.toDataURL('image/png');
                        const link = document.createElement('a');
                        link.href = imgData;
                        link.download = `THEAI_Statement_Photo_${selectedPreviewStatement.name.replace(/\s+/g, '_')}.png`;
                        link.click();
                      }).catch((err) => {
                        console.error('Canvas statement error: ', err);
                        alert('Error compiling ledger statement photo file.');
                      });
                    }}
                    className={`p-2 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer border ${
                      isNeon
                        ? 'border-emerald-500/20 bg-neutral-900 text-emerald-400 hover:bg-emerald-500/10'
                        : 'border-fuchsia-500/20 bg-neutral-900 text-fuchsia-400 hover:bg-fuchsia-500/10'
                    }`}
                  >
                    <Image className="w-3.5 h-3.5" />
                    Download Photo
                  </button>

                  <button
                    onClick={() => {
                      const style = document.createElement('style');
                      style.innerHTML = `
                        @media print {
                          body * { display: none !important; }
                          #preview-statement-render-capture, #preview-statement-render-capture * { display: block !important; }
                          #preview-statement-render-capture { position: absolute !important; left: 0 !important; top: 0 !important; width: 100% !important; background: #fff !important; color: #000 !important; border: none !important; }
                          #preview-statement-render-capture span, #preview-statement-render-capture p, #preview-statement-render-capture table { color: #000 !important; }
                        }
                      `;
                      document.head.appendChild(style);
                      window.print();
                      document.head.removeChild(style);
                    }}
                    className={`p-2 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer border ${
                      isNeon
                        ? 'border-emerald-500/20 bg-neutral-900 text-emerald-400 hover:bg-emerald-500/10'
                        : 'border-fuchsia-500/20 bg-neutral-900 text-fuchsia-400 hover:bg-fuchsia-500/10'
                    }`}
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Print / PDF
                  </button>
                </div>

                <button
                  onClick={() => downloadCustomerStatement(selectedPreviewStatement.name, selectedPreviewStatement.data)}
                  className="w-full p-2 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer bg-neutral-900 hover:bg-neutral-850 text-white border border-neutral-800"
                >
                  <Download className="w-3.5 h-3.5" />
                  Get Offline HTML Statement Document
                </button>

                {/* Gmail secure sending portal integration */}
                <div className="mt-2 pt-3 border-t border-neutral-900/50 space-y-2">
                  <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold flex items-center gap-1.5 font-mono">
                    <Mail className={`w-3.5 h-3.5 ${isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}`} />
                    Gmail Statement Dispatch
                  </span>
                  
                  {gmailConnected ? (
                    <div className="space-y-2">
                      <div className="relative">
                        <input
                          type="email"
                          required
                          value={recipientEmail}
                          onChange={(e) => setRecipientEmail(e.target.value)}
                          placeholder="recipient@domain.com"
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 pl-3 pr-24 text-white text-xs outline-none focus:border-neutral-750 font-mono"
                        />
                        <button
                          onClick={() => handleSendStatementEmail(selectedPreviewStatement.name, selectedPreviewStatement.data, recipientEmail)}
                          disabled={emailSending}
                          className={`absolute right-1.5 top-1.5 py-1 px-3 rounded-lg font-bold uppercase tracking-wider text-[10px] transition-colors cursor-pointer flex items-center gap-1 ${
                            isNeon 
                              ? 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20' 
                              : 'bg-fuchsia-500/10 hover:bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/20'
                          }`}
                        >
                          {emailSending ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Send className="w-3 h-3" />
                          )}
                          Send
                        </button>
                      </div>
                      
                      {emailStatus && (
                        <div className={`p-2 rounded font-mono text-[10px] text-center border ${
                          emailStatus.startsWith('DISPATCHED') 
                            ? 'bg-emerald-950/20 border-emerald-500/20 text-emerald-400' 
                            : emailStatus.startsWith('REJECTED')
                              ? 'bg-red-950/20 border-red-500/20 text-red-100'
                              : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                        }`}>
                          {emailStatus}
                        </div>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={handleConnectGmail}
                      disabled={gmailLoading}
                      className="w-full p-2.5 rounded-xl font-bold font-mono tracking-wider text-[10px] uppercase transition-all border border-dashed border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-white bg-neutral-950 hover:bg-neutral-900 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      {gmailLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Lock className="w-3.5 h-3.5" />
                      )}
                      Link Gmail to Dispatch Electronic Statement
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
