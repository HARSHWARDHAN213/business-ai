/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Plus, Trash2, Printer, Save, RefreshCw, X, Image, Download } from 'lucide-react';
import html2canvas from 'html2canvas';
import { Transaction, TransactionItem, TransactionType, AppTheme, UserSession } from '../types';

interface BillingInvoiceProps {
  session: UserSession;
  theme: AppTheme;
  onSaveInvoice: (invoice: Omit<Transaction, 'id' | 'date'>) => void;
  onClose: () => void;
}

export default function BillingInvoice({ session, theme, onSaveInvoice, onClose }: BillingInvoiceProps) {
  const isNeon = theme === 'NEON_MONOCHROME';
  const [draft, setDraft] = useState<any>(() => {
    const saved = localStorage.getItem('THEAI_HUB_INVOICE_DRAFT');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved invoice draft', e);
      }
    }
    return null;
  });

  const [customerName, setCustomerName] = useState(() => draft?.customerName ?? '');
  const [customerPhone, setCustomerPhone] = useState(() => draft?.customerPhone ?? '');
  const [billId, setBillId] = useState(() => draft?.billId ?? '');
  const [type, setType] = useState<TransactionType>(() => draft?.type ?? 'PAID');
  const [description, setDescription] = useState(() => draft?.description ?? '');
  
  // Line items state
  const [items, setItems] = useState<TransactionItem[]>(() => draft?.items ?? [
    { name: 'Core Compute Smart Chip', quantity: 1, price: 1250 }
  ]);
  
  // Custom single item manual entry state
  const [newItemName, setNewItemName] = useState('');
  const [newItemQty, setNewItemQty] = useState(1);
  const [newItemPrice, setNewItemPrice] = useState(0);

  // Generate original Bill ID on load only if none exists
  useEffect(() => {
    if (!billId) {
      const formatNum = Math.floor(1000 + Math.random() * 9000);
      setBillId(`THEAI-${new Date().getFullYear()}-${formatNum}`);
    }
  }, [billId]);

  // Real-time auto-saving mechanism for the billing inputs
  useEffect(() => {
    const draftData = {
      customerName,
      customerPhone,
      billId,
      type,
      description,
      items
    };
    localStorage.setItem('THEAI_HUB_INVOICE_DRAFT', JSON.stringify(draftData));
  }, [customerName, customerPhone, billId, type, description, items]);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim() || newItemPrice <= 0 || newItemQty <= 0) return;
    
    setItems((prev) => [
      ...prev,
      {
        name: newItemName.trim(),
        quantity: Number(newItemQty),
        price: Number(newItemPrice)
      }
    ]);

    setNewItemName('');
    setNewItemQty(1);
    setNewItemPrice(0);
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Automated Calculations
  const calculatedSubtotal = items.reduce((total, item) => total + (item.quantity * item.price), 0);
  // Default tax-equivalent processing or handling fee
  const calculatedTax = Math.round(calculatedSubtotal * 0.05); // 5% fee
  const calculatedGrandTotal = calculatedSubtotal + calculatedTax;

  const handleSaveAndPrint = () => {
    if (!customerName.trim()) {
      alert('Kindly configure an Authorized Customer Name before generating the ledger sync.');
      return;
    }
    
    onSaveInvoice({
      billId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      amount: calculatedGrandTotal,
      type,
      description: description.trim() || `Invoice ${billId} generated for ${customerName}`,
      items
    });

    // Clear invoice auto-saved draft since it's successfully finalized!
    localStorage.removeItem('THEAI_HUB_INVOICE_DRAFT');

    // Bring up system print dialog
    setTimeout(() => {
      window.print();
    }, 300);
  };

  const downloadInvoicePhoto = () => {
    const input = document.getElementById('printable-invoice');
    if (!input) return;

    // Temporarily hide parts not suited for export if any
    const deleteButtons = input.querySelectorAll('button');
    deleteButtons.forEach((btn: any) => btn.style.visibility = 'hidden');

    html2canvas(input, {
      backgroundColor: '#030303',
      scale: 2, // ultra high-res
      useCORS: true,
      logging: false,
    }).then((canvas) => {
      // restore elements
      deleteButtons.forEach((btn: any) => btn.style.visibility = 'visible');
      
      const imgData = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = imgData;
      link.download = `THEAI_Invoice_${billId}_${customerName.trim().replace(/\s+/g, '_') || 'Customer'}.png`;
      link.click();
    }).catch(err => {
      console.error("Error creating image canvas: ", err);
      deleteButtons.forEach((btn: any) => btn.style.visibility = 'visible');
      alert('Could not download image directly. Try standard compiler print/PDF options.');
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`w-full max-w-4xl rounded-2xl bg-neutral-950 border overflow-hidden flex flex-col md:flex-row ${
          isNeon ? 'border-emerald-500/40' : 'border-fuchsia-100/10'
        }`}
      >
        {/* Input panel Left */}
        <div className="flex-1 p-6 border-b md:border-b-0 md:border-r border-neutral-800/80 max-h-[85vh] overflow-y-auto">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold flex items-center gap-2 font-mono">
              <FileText className={isNeon ? 'text-emerald-400' : 'text-fuchsia-400'} />
              Invoice Compiler
            </h3>
            <div className="flex items-center gap-2">
              {(customerName || customerPhone || items.length > 0 || description) && (
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("Reset compile draft and clear all fields?")) {
                      setCustomerName('');
                      setCustomerPhone('');
                      const formatNum = Math.floor(1000 + Math.random() * 9000);
                      setBillId(`THEAI-${new Date().getFullYear()}-${formatNum}`);
                      setType('PAID');
                      setDescription('');
                      setItems([]);
                      localStorage.removeItem('THEAI_HUB_INVOICE_DRAFT');
                    }
                  }}
                  className="px-2 py-1 text-[9px] font-mono rounded bg-red-950/40 text-red-400 border border-red-500/20 hover:bg-red-900/20 cursor-pointer uppercase transition-all"
                  title="Wipe form and draft storage"
                >
                  Clear Draft
                </button>
              )}
              <span className="text-[9px] font-mono text-neutral-500 uppercase tracking-widest hidden sm:inline animate-pulse">
                Auto-saved
              </span>
              <button
                onClick={onClose}
                className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            {/* Customer Information */}
            <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/70 space-y-3">
              <div className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold">
                Customer & Account Registry
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 mb-1">Customer Identifier Name</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full bg-black border border-neutral-800 focus:border-neutral-700 rounded-lg p-2 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Contact Phone (Optional)</label>
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. +91 9876543210"
                    className="w-full bg-black border border-neutral-800 focus:border-neutral-700 rounded-lg p-2 text-white outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Bill Info & Catalog */}
            <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/70 space-y-3">
              <div className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold">
                Taxation ID & Transaction Type
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 mb-1">Bill / Txn ID</label>
                  <input
                    type="text"
                    value={billId}
                    onChange={(e) => setBillId(e.target.value)}
                    className="w-full bg-black border border-neutral-800 rounded-lg p-2 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Payment Classification</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as TransactionType)}
                    className="w-full bg-black border border-neutral-800 rounded-lg p-2 text-white outline-none cursor-pointer"
                  >
                    <option value="PAID">PAID (Full Settled Payment)</option>
                    <option value="DUE">DUE (Udhari/Pending)</option>
                    <option value="RECOVERY">RECOVERY (Debt Clearance)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">Ledger Note / Description</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Purchase of premium microchips"
                  className="w-full bg-black border border-neutral-800 focus:border-neutral-700 rounded-lg p-2 text-white outline-none"
                />
              </div>
            </div>

            {/* Catalog Items Input */}
            <form onSubmit={handleAddItem} className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/70 space-y-3">
              <div className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold flex justify-between items-center">
                <span>Add Ledger Item / Service</span>
                <span className="text-emerald-400 text-[9px] font-normal uppercase">Auto-Calculates Row subtotals</span>
              </div>
              
              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-6">
                  <input
                    type="text"
                    required
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    placeholder="Product / Service"
                    className="w-full bg-black border border-neutral-800 rounded-lg p-2 text-white outline-none text-xs"
                  />
                </div>
                <div className="col-span-2">
                  <input
                    type="number"
                    min="1"
                    required
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(Math.max(1, Number(e.target.value)))}
                    placeholder="Qty"
                    className="w-full bg-black border border-neutral-800 rounded-lg p-2 text-white outline-none text-xs text-center"
                  />
                </div>
                <div className="col-span-3">
                  <input
                    type="number"
                    min="1"
                    required
                    value={newItemPrice === 0 ? '' : newItemPrice}
                    onChange={(e) => setNewItemPrice(Math.max(0, Number(e.target.value)))}
                    placeholder="Price (INR)"
                    className="w-full bg-black border border-neutral-800 rounded-lg p-2 text-white outline-none text-xs text-center"
                  />
                </div>
                <div className="col-span-1 flex items-center justify-center">
                  <button
                    type="submit"
                    className={`p-2 rounded-lg cursor-pointer ${
                      isNeon ? 'bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-black' : 'bg-fuchsia-500/10 hover:bg-fuchsia-500 text-fuchsia-400 hover:text-white'
                    } transition-colors`}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>

        {/* Live Digital Receipt Sandbox (Right) */}
        <div className="flex-1 p-6 bg-neutral-950 flex flex-col justify-between max-h-[85vh]">
          <div>
            <div className="flex justify-between items-end border-b border-neutral-800/80 pb-3 mb-4">
              <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-mono">
                Live Output Preview
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-900/30 text-emerald-400 border border-emerald-500/20 font-mono font-medium animate-pulse">
                Auto-Synced
              </span>
            </div>

            {/* Printable Frame wrapper */}
            <div id="printable-invoice" className="p-6 rounded-xl bg-black border border-neutral-900 shadow-xl font-mono text-xs text-neutral-300 relative">
              {/* Header */}
              <div className="text-center mb-6 pb-4 border-b border-neutral-900 border-dashed">
                <span className="text-xs font-bold uppercase tracking-widest text-white">
                  {session.shopName}
                </span>
                <p className="text-[9px] text-neutral-500 mt-0.5 uppercase">
                  Operator Signature: {session.username}
                </p>
                <p className="text-[8px] text-neutral-600 mt-1 uppercase">
                  The AI Hub Smart Ledger Integration
                </p>
              </div>

              {/* Meta */}
              <div className="grid grid-cols-2 gap-2 text-[10px] mb-4 pb-4 border-b border-neutral-900 border-dashed">
                <div>
                  <span className="text-neutral-500">BILL ID:</span>{' '}
                  <span className="text-white font-bold">{billId}</span>
                </div>
                <div className="text-right">
                  <span className="text-neutral-500">DATE:</span>{' '}
                  <span className="text-white">{new Date().toLocaleDateString()}</span>
                </div>
                <div>
                  <span className="text-neutral-500">CLIENT:</span>{' '}
                  <span className="text-white font-semibold uppercase">
                    {customerName || 'UNSPECIFIED'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-neutral-500">CLASSIFIED:</span>{' '}
                  <span className={`font-semibold px-1 rounded ${
                    type === 'PAID' ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20' :
                    type === 'DUE' ? 'bg-red-950/40 text-red-400 border border-red-500/20' :
                    'bg-cyan-950/40 text-cyan-400 border border-cyan-500/20'
                  }`}>
                    {type}
                  </span>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-2 mb-6 min-h-[100px]">
                <div className="grid grid-cols-12 text-[10px] text-neutral-500 border-b border-neutral-900 pb-1 font-bold">
                  <span className="col-span-6 text-left">SPECIFICATION</span>
                  <span className="col-span-2 text-center">QTY</span>
                  <span className="col-span-2 text-right">UNIT</span>
                  <span className="col-span-2 text-right">TOTAL</span>
                </div>

                <AnimatePresence initial={false}>
                  {items.map((item, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className="grid grid-cols-12 items-center text-[10px] text-neutral-300 py-1 border-b border-neutral-900/50"
                    >
                      <span className="col-span-6 truncate font-medium flex items-center gap-1.5">
                        <button
                          onClick={() => handleRemoveItem(idx)}
                          className="text-red-500 hover:text-red-400 cursor-pointer p-0.5 flex items-center justify-center opacity-70 hover:opacity-100 print:hidden"
                          title="Remove row"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                        {item.name}
                      </span>
                      <span className="col-span-2 text-center">{item.quantity}</span>
                      <span className="col-span-2 text-right">₹{item.price.toLocaleString()}</span>
                      <span className="col-span-2 text-right font-semibold text-white">
                        ₹{(item.quantity * item.price).toLocaleString()}
                      </span>
                    </motion.div>
                  ))}
                </AnimatePresence>

                {items.length === 0 && (
                  <div className="text-center text-neutral-600 text-[10px] py-4">
                    [ No active items compiled inside digital invoice ]
                  </div>
                )}
              </div>

              {/* Calculations Stack */}
              <div className="space-y-1.5 pt-3 border-t border-neutral-900 border-dashed text-[10px]">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Subtotal Compilations:</span>
                  <span className="text-neutral-300">₹{calculatedSubtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Convenience handling tax (5%):</span>
                  <span className="text-neutral-300">₹{calculatedTax.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs border-t border-neutral-900 pt-2 font-bold text-white">
                  <span>Grand Total Liability:</span>
                  <span className={isNeon ? 'text-emerald-400' : 'text-fuchsia-400'}>
                    ₹{calculatedGrandTotal.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Footer validation */}
              <div className="mt-8 pt-4 border-t border-neutral-900 border-dotted text-center text-[8px] text-neutral-500 uppercase leading-relaxed font-mono">
                Autogenerated Ledger Token ID: {Math.random().toString(36).substring(2, 10).toUpperCase()}
                <br />
                Secured locally under THEAi Hub Cryptography suite
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="mt-6 flex flex-col gap-2 print:hidden intense-footer">
            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl border border-neutral-800 text-neutral-400 text-xs hover:text-white transition-colors cursor-pointer font-mono"
              >
                Cancel Block
              </button>
              
              <button
                type="button"
                onClick={downloadInvoicePhoto}
                disabled={items.length === 0 || !customerName.trim()}
                className={`flex-1 py-2.5 px-4 rounded-xl border font-bold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  isNeon
                    ? 'border-emerald-500/20 bg-neutral-900/60 hover:bg-emerald-500/5 text-emerald-400 disabled:opacity-40'
                    : 'border-fuchsia-500/20 bg-neutral-900/60 hover:bg-fuchsia-500/5 text-fuchsia-400 disabled:opacity-40'
                }`}
              >
                <Image className="w-4 h-4" />
                Save Bill Photo
              </button>
            </div>
            
            <button
              onClick={handleSaveAndPrint}
              disabled={items.length === 0 || !customerName.trim()}
              className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isNeon
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-black disabled:bg-emerald-950/20 disabled:text-neutral-600'
                  : 'bg-gradient-to-r from-fuchsia-500 to-cyan-500 hover:opacity-95 text-white disabled:opacity-40'
              }`}
            >
              <Printer className="w-4 h-4" />
              Compile & Print / Save PDF
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
