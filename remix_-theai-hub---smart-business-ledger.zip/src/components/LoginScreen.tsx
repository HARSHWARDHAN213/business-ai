/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, Shield, ArrowRight, Sparkles, Building2, User, Mail, BookOpen, Fingerprint, Coins, BarChart3, ChevronRight, LogIn } from 'lucide-react';
import { AppTheme, UserSession } from '../types';
import { loginWithGoogle } from '../firebase';

interface LoginScreenProps {
  onLoginSuccess: (session: UserSession) => void;
  theme: AppTheme;
}

export default function LoginScreen({ onLoginSuccess, theme }: LoginScreenProps) {
  // Use state to toggle between Welcome hero page and formal operator credentials form
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [shopName, setShopName] = useState('Lodhi Digital Emporium');
  const [username, setUsername] = useState('Harshvardhan Singh');
  const [email, setEmail] = useState('lodhiverma678@gmail.com');
  const [error, setError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const isNeon = theme === 'NEON_MONOCHROME';

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setError('');
    try {
      localStorage.setItem('THEAI_HUB_PENDING_SHOPNAME', shopName || 'Lodhi Digital Emporium');
      await loginWithGoogle();
    } catch (e: any) {
      console.error(e);
      setError(e?.message || 'Google Sign-In was cancelled or rejected by secure guard.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shopName.trim() || !username.trim() || !email.trim()) {
      setError('All fields are required to secure the encrypted ledger portal.');
      return;
    }
    
    // Simple email regex validation
    if (!email.includes('@')) {
      setError('Please provide a valid authorized billing email address.');
      return;
    }

    onLoginSuccess({
      isLoggedIn: true,
      shopName: shopName.trim(),
      username: username.trim(),
      email: email.trim()
    });
  };

  const handleQuickLogin = () => {
    onLoginSuccess({
      isLoggedIn: true,
      shopName: 'Lodhi Digital Emporium',
      username: 'Harshvardhan Singh Lodhi',
      email: 'lodhiverma678@gmail.com'
    });
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center px-4 relative overflow-hidden cyber-grid bg-[#030303]">
      {/* Decorative Cyber Background Effects */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className={`absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl ${isNeon ? 'bg-emerald-500/20' : 'bg-fuchsia-600/20'}`}></div>
        <div className={`absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl ${isNeon ? 'bg-cyan-500/20' : 'bg-violet-600/20'}`}></div>
      </div>

      <AnimatePresence mode="wait">
        {!showLoginForm ? (
          /* ================= WELCOME SCREEN ================= */
          <motion.div
            key="welcome"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="w-full max-w-2xl z-10 text-center space-y-6 px-2"
          >
            {/* Cyber Ribbon */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900 border border-neutral-800 text-xs text-neutral-400 tracking-wider uppercase font-mono">
              <span className={`w-2.5 h-2.5 rounded-full ${isNeon ? 'bg-emerald-400 animate-pulse' : 'bg-fuchsia-400 animate-pulse'}`}></span>
              LIVE HUB BROADCAST &bull; SECURED WORKSPACE
            </div>

            {/* Giant Title */}
            <div>
              <h1 className="text-5xl md:text-6xl font-extrabold tracking-tighter mb-2 font-sans select-none">
                <span className="text-white">THE</span>
                <span className={isNeon ? 'text-emerald-400 font-mono tracking-widest' : 'text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400'}>
                  {` Ai Hub`}
                </span>
              </h1>
              <p className="text-xs md:text-sm font-mono text-neutral-400 uppercase tracking-widest max-w-md mx-auto">
                Smart Business Ledger Protocol
              </p>
            </div>

            {/* Founder Tribute Box */}
            <div className={`relative p-5 rounded-2xl bg-neutral-900/60 border ${
              isNeon ? 'border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.05)]' : 'border-fuchsia-500/20 shadow-[0_0_15px_rgba(236,72,153,0.05)]'
            } max-w-md mx-auto`}>
              <div className="text-[10px] text-neutral-500 font-mono uppercase tracking-widest mb-1.5 flex items-center justify-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                FOUNDER & DIRECTOR OF THEAI HUB
              </div>
              <div className="text-lg font-black tracking-tight text-white uppercase font-sans">
                Harshvardhan Singh Lodhi
              </div>
              <div className="text-[9px] text-neutral-500 uppercase font-mono mt-1">
                Architecting local intelligence tools for modern retailers
              </div>
            </div>

            {/* Key capabilities cards (Bento Style) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left pt-2">
              <div className="p-4 rounded-xl bg-black/40 border border-neutral-900 flex flex-col justify-between">
                <div>
                  <div className="p-2 w-fit rounded-lg bg-neutral-900 border border-neutral-800 mb-3">
                    <Coins className="w-4 h-4 text-emerald-400" />
                  </div>
                  <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-1">
                    Digital Billing
                  </h3>
                  <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">
                    Automate tax totals, compile items, and print instant PDF bills in one click.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-black/40 border border-neutral-900 flex flex-col justify-between">
                <div>
                  <div className="p-2 w-fit rounded-lg bg-neutral-900 border border-neutral-800 mb-3">
                    <BarChart3 className="w-4 h-4 text-fuchsia-400" />
                  </div>
                  <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-1">
                    Udhari Tracking
                  </h3>
                  <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">
                    Show cash paid, track remaining balance for each customer, & download bills.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-black/40 border border-neutral-900 flex flex-col justify-between">
                <div>
                  <div className="p-2 w-fit rounded-lg bg-neutral-900 border border-neutral-800 mb-3">
                    <Fingerprint className="w-4 h-4 text-cyan-400" />
                  </div>
                  <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-1">
                    Offline Sync
                  </h3>
                  <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">
                    Guaranteed persistent data safety on local device with AI-ready support.
                  </p>
                </div>
              </div>
            </div>

            {/* Glowing Main Login / Launch Button */}
            <div className="pt-4 flex flex-col gap-3 max-w-sm mx-auto">
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoggingIn}
                className={`w-full py-4 px-6 rounded-2xl font-extrabold text-sm tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-2.5 cursor-pointer ${
                  isNeon
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-[0_0_30px_rgba(16,185,129,0.4)] font-mono'
                    : 'bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-500 hover:opacity-95 text-white shadow-[0_0_30px_rgba(217,70,239,0.35)]'
                } disabled:opacity-50`}
              >
                <LogIn className="w-4 h-4" />
                {isLoggingIn ? 'Connecting Secure Guard...' : 'Sign In with Google'}
              </button>

              <div className="flex gap-2.5 items-center">
                <button
                  onClick={() => setShowLoginForm(true)}
                  className="flex-1 py-3 px-4 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-neutral-900 text-neutral-300 hover:text-white text-xs font-bold uppercase tracking-wider font-mono transition-colors cursor-pointer"
                >
                  Operator Setup
                </button>

                <button
                  onClick={handleQuickLogin}
                  className="flex-1 py-3 px-4 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-neutral-900 text-neutral-400 hover:text-white text-[10px] font-bold uppercase tracking-wider font-mono transition-colors cursor-pointer"
                >
                  Demo Bypass &rarr;
                </button>
              </div>
            </div>

            {/* Safety Indicator Badge */}
            <div className="pt-2 text-[10px] text-neutral-600 font-mono uppercase tracking-widest flex items-center justify-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-neutral-700" />
              THEAi Hub Cryptographic Ledger active on Device Storage
            </div>
          </motion.div>
        ) : (
          /* ================= LOGIN FORM SCREEN ================= */
          <motion.div
            key="login-form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-lg z-10"
          >
            {/* Header */}
            <div className="text-center mb-6">
              <h2 className="text-3xl font-black tracking-tight text-white mb-1.5 font-sans">
                Set Operator Credentials
              </h2>
              <p className="text-xs text-neutral-500 font-mono uppercase tracking-widest">
                Configure store parameters to sync encryption headers
              </p>
            </div>

            {/* Dynamic Container */}
            <div className={`relative p-8 rounded-2xl bg-black/80 backdrop-blur-xl border transition-all duration-500 ${
              isNeon 
                ? 'border-emerald-500/30 shadow-[0_0_25px_rgba(16,185,129,0.1)]' 
                : 'border-fuchsia-500/30 shadow-[0_0_30px_rgba(217,70,239,0.15)]'
            }`}>
              {/* Corner decor */}
              <div className={`absolute -top-px -left-px w-6 h-px ${isNeon ? 'bg-emerald-400' : 'bg-fuchsia-400'}`}></div>
              <div className={`absolute -top-px -left-px w-px h-6 ${isNeon ? 'bg-emerald-400' : 'bg-fuchsia-400'}`}></div>

              <form onSubmit={handleLogin} className="space-y-4">
                {error && (
                  <div className="p-3 text-xs font-mono rounded-lg bg-red-950/40 border border-red-500/30 text-red-400">
                    ⚡ SECURITY_REJECTED: {error}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-1.5 font-mono">
                    Store / Shop Name
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                    <input
                      type="text"
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      placeholder="e.g. Lodhi Electronics"
                      className="w-full bg-neutral-900 border border-neutral-800 focus:border-neutral-600 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-neutral-600 outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-1.5 font-mono">
                    Operator / Owner Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="e.g. Harshvardhan"
                      className="w-full bg-neutral-900 border border-neutral-800 focus:border-neutral-600 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-neutral-600 outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-1.5 font-mono">
                    Authorized Billing Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="operator@business.com"
                      className="w-full bg-neutral-900 border border-neutral-800 focus:border-neutral-600 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-neutral-600 outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Back & Forward buttons inline */}
                <div className="flex gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowLoginForm(false)}
                    className="flex-1 py-3 px-4 rounded-xl border border-neutral-800 text-neutral-400 hover:text-white text-xs font-mono transition-colors"
                  >
                    &larr; Back
                  </button>
                  <button
                    type="submit"
                    className={`flex-[2] py-3 px-4 rounded-xl font-bold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isNeon 
                        ? 'bg-emerald-500 hover:bg-emerald-200 text-black shadow-lg font-mono' 
                        : 'bg-gradient-to-r from-fuchsia-500 to-cyan-500 hover:opacity-90 text-white'
                    }`}
                  >
                    Enter Workspace
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>

              {/* Manual Direct Skip options */}
              <div className="mt-6 pt-6 border-t border-neutral-800/60 text-center">
                <button
                  type="button"
                  onClick={handleQuickLogin}
                  className="text-xs text-neutral-500 hover:text-emerald-400 font-mono transition-colors cursor-pointer inline-flex items-center gap-1"
                >
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  Quick-Bypass with Sandbox Credentials
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

