/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from './firebase';

// Cache Gmail access token strictly in-memory (no localStorage for security compliance)
let cachedGmailToken: string | null = null;
let isAuthenticating = false;

// Configured Gmail scopes
export const GMAIL_SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.readonly'
];

/**
 * Open popup to authenticate user explicitly with Gmail scopes.
 */
export async function connectGmail(): Promise<string> {
  if (isAuthenticating) {
    throw new Error('Gmail authentication protocol is already active.');
  }
  
  isAuthenticating = true;
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    
    // Add scopes incrementally to preserve least privileges
    GMAIL_SCOPES.forEach(scope => provider.addScope(scope));

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    
    if (!credential?.accessToken) {
      throw new Error('Google Auth did not return a valid secure access token.');
    }

    cachedGmailToken = credential.accessToken;
    return cachedGmailToken;
  } catch (error: any) {
    console.error('Gmail Authorization Refused:', error);
    throw error;
  } finally {
    isAuthenticating = false;
  }
}

/**
 * Retrieve cached memory token. Let consumer know if re-auth might be needed.
 */
export function getGmailToken(): string | null {
  return cachedGmailToken;
}

/**
 * Manually inject token if retrieved through regular flow (or for testing)
 */
export function setGmailToken(token: string) {
  cachedGmailToken = token;
}

/**
 * Wipe connection cache on Sign Out
 */
export function disconnectGmail() {
  cachedGmailToken = null;
}

/**
 * Helper to construct and encode standard RFC 2822 email payload as base64url.
 */
function buildRawEmail(to: string, subject: string, htmlContent: string): string {
  // Safe UTF-8 Base64 conversion
  const encoder = new TextEncoder();
  const utf8Data = encoder.encode(htmlContent);
  
  const headers = [
    `To: ${to}`,
    `Subject: ${subject}`,
    'MIME-Version: 1.0',
    'Content-Type: text/html; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    ''
  ].join('\r\n');

  // Convert HTML content chunk to standard base64 chunk
  let binary = '';
  const bytes = new Uint8Array(utf8Data);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  const base64Body = btoa(binary).replace(/.{76}/g, '$&\r\n');

  const fullRawMessage = headers + base64Body;

  // Final base64url encoding for Gmail send REST ingestion spec
  return btoa(unescape(encodeURIComponent(fullRawMessage)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Send invoice or statement email using official Gmail REST API.
 */
export async function sendGmailMessage(to: string, subject: string, htmlContent: string): Promise<any> {
  const token = getGmailToken();
  if (!token) {
    throw new Error('GMAIL_NOT_CONNECTED: Gmail authentication token is stale or unestablished.');
  }

  const rawMessage = buildRawEmail(to, subject, htmlContent);

  const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      raw: rawMessage
    })
  });

  if (!response.ok) {
    const errorDetails = await response.text();
    throw new Error(`Gmail Dispatch Rejected: [${response.status}] ${errorDetails}`);
  }

  return response.json();
}

export interface SentReceiptLog {
  id: string;
  to: string;
  subject: string;
  snippet: string;
  date: string;
}

/**
 * Lists latest 10 emails sent by this application.
 * Filters by subject context 'THEAi Hub' to maintain ledger security and privacy boundaries.
 */
export async function listSentLedgerEmails(): Promise<SentReceiptLog[]> {
  const token = getGmailToken();
  if (!token) {
    return [];
  }

  try {
    // Search query: restrict to emails sent by "me" containing "THEAi Hub" in subject
    const queryParam = encodeURIComponent('subject:"THEAi Hub"');
    const listRes = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${queryParam}&maxResults=10`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!listRes.ok) {
      console.warn('Could not retrieve Gmail message indexes:', listRes.statusText);
      return [];
    }

    const listData = await listRes.json();
    if (!listData.messages || listData.messages.length === 0) {
      return [];
    }

    // Parallel detail fetch for batch performance
    const detailPromises = listData.messages.map(async (msgMsg: { id: string }) => {
      try {
        const detailRes = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${msgMsg.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=To&metadataHeaders=Date`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (!detailRes.ok) return null;
        const details = await detailRes.json();

        const headers = details.payload?.headers || [];
        const toHeader = headers.find((h: any) => h.name.toLowerCase() === 'to')?.value || 'Unknown Customer';
        const subjectHeader = headers.find((h: any) => h.name.toLowerCase() === 'subject')?.value || 'No Subject';
        const dateHeader = headers.find((h: any) => h.name.toLowerCase() === 'date')?.value || new Date().toISOString();

        return {
          id: details.id,
          to: toHeader,
          subject: subjectHeader,
          snippet: details.snippet || '',
          date: dateHeader
        } as SentReceiptLog;
      } catch (e) {
        console.error(`Gmail item detail extraction aborted for ID ${msgMsg.id}:`, e);
        return null;
      }
    });

    const results = await Promise.all(detailPromises);
    return results.filter((r): r is SentReceiptLog => r !== null);
  } catch (error) {
    console.error('Failed to query ledger logs from Gmail:', error);
    return [];
  }
}
